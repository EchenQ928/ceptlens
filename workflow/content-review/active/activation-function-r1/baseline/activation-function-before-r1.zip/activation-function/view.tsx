import { Callout, CodeBlock, Comparison, CuratedVisual, DepthwiseConvolutionExplorer, EngineeringBoundaries, Flow, Formula, Paragraph, TermSection, defineTermView } from "@term-sdk";
import styles from "./styles.module.css";

function TermBody() {
  return <div className={styles.packageRoot}>
      <TermSection id="position" title="它位于哪里">
        <Flow steps={[{"label":"线性计算","detail":"输入乘权重再加偏置，得到中间值 z。"},{"label":"激活","detail":"把 z 送入非线性函数 f，得到 h=f(z)。"},{"label":"继续传递","detail":"h 作为下一层的输入，或交给[[term:output-layer|输出层]]。"}]} />
        <Formula expression="h=f(Wx+b)" caption="一层中常见的线性变换加激活" symbols={[{"symbol":"x","meaning":"本层输入"},{"symbol":"W,b","meaning":"本层可学习的权重与偏置"},{"symbol":"f","meaning":"激活函数"},{"symbol":"h","meaning":"送往下一层的输出"}]} />
      </TermSection>
      <TermSection id="choices" title="常见选择">
        <Comparison columns={["函数","直观行为","常见位置"]} rows={[["ReLU","负数变成 0，正数保持不变","CNN、MLP 隐藏层"],["GELU / SiLU","平滑地抑制较小输入","Transformer 与现代网络隐藏层"],["Sigmoid","把数值压到 0 到 1","二分类输出或门控"],["Softmax","把一组分数转成总和为 1 的分布","多分类输出、Attention 权重"]]} />
      </TermSection>
      <EngineeringBoundaries items={["输出层激活要与任务和损失函数配套，不能只按习惯选择。","硬件部署时需要确认目标 NPU 对 GELU、SiLU 等算子的原生支持和融合能力。"]} />
    </div>;
}

export default defineTermView({ termId: "activation-function", Component: TermBody });
