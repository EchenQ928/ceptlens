import {Callout,CodeBlock,Formula,TermSection,defineTermView} from '@term-sdk';
import {TrainingAnimation} from './explorer';
import {annotatedPrediction} from './timeline';
import {trainingCode} from './pytorch';
import styles from './styles.module.css';

function TermBody(){
  return <div className={styles.root}>
    <TermSection id="function" title="先看清：对哪个函数、哪些参数求导">
      <p>输入经过两层计算得到预测，再与目标比较得到损失。<strong>反向传播要求的是损失 L 对每个权重、偏置的偏导。</strong></p>
      <div className={styles.functionMap}>
        <div><span className={styles.mapLabel}>预测函数 · 括号下标出中间结果</span><Formula expression={annotatedPrediction} symbols={[]}/></div>
        <div><span className={styles.mapLabel}>平方损失</span><Formula expression={String.raw`L=(\hat y-y)^2`} symbols={[]}/></div>
      </div>
      <div className={styles.legend}><span><b>x、y</b> 输入与目标，固定不变</span><span><b>w₁、b₁、w₂、b₂</b> 需要学习的四个参数</span></div>
    </TermSection>
    <TermSection id="training" title="跟着同一个网络，完成两轮训练">
      <p><strong>前向计算 → 反向求梯度 → 更新参数。</strong>红框标出当前计算的位置，下面同步显示公式和数值。先点“下一步”，也可以播放完整过程。</p>
      <TrainingAnimation/>
      <Callout tone="key" title="为什么第二轮要重新求梯度？">{'偏导的表达式不变，代入的数值会变。第一轮预测为 2，损失对预测的偏导是 2 × (2 − 3) = −2；第二轮预测为 3.125，这个偏导就变成 0.25。反向传播求出当前梯度，优化器再按“旧值 − 学习率 × 梯度”更新参数。'}</Callout>
      <details className={styles.details}><summary>用 PyTorch 复现这两轮训练</summary><CodeBlock language="python" code={trainingCode} caption="backward() 计算梯度，step() 更新参数。动画把一次 step() 中四个参数的新值分别展示，四项都使用同一轮的旧值与梯度。"/></details>
      <details className={styles.details}><summary>多条路径、多个样本与 ReLU 的边界</summary><p>同一参数通过多条路径影响损失时，各路径的贡献相加。批次损失取平均时，参数梯度也取平均。ReLU 在 z &gt; 0 时导数为 1，在 z &lt; 0 时为 0；z = 0 处不可导，PyTorch 约定取 0。</p></details>
      <p className={styles.source}>参考：<a href="https://docs.pytorch.org/tutorials/beginner/basics/autogradqs_tutorial.html" target="_blank" rel="noreferrer">PyTorch · 自动微分</a><a href="https://cs231n.github.io/optimization-2/" target="_blank" rel="noreferrer">Stanford CS231n · 计算图与链式法则</a></p>
    </TermSection>
  </div>;
}
export default defineTermView({termId:'backpropagation',Component:TermBody});
