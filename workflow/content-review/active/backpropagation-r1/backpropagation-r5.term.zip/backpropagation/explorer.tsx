import {useEffect,useRef,useState} from 'react';
import {Formula} from '@term-sdk';
import {fmt,parameterKeys,parameterNames,parameterSymbols} from './model';
import {partial,timeline,type Frame,type NodeKey} from './timeline';
import styles from './styles.module.css';

const nodes:{key:NodeKey;symbol:string;label:string;rule:string}[]=[
  {key:'x',symbol:'x',label:'输入',rule:'同一个样本'},
  {key:'z',symbol:'z',label:'第一层',rule:'w₁x + b₁'},
  {key:'h',symbol:'h',label:'激活',rule:'ReLU(z)'},
  {key:'prediction',symbol:'ŷ',label:'第二层 · 预测',rule:'w₂h + b₂'},
  {key:'loss',symbol:'L',label:'损失',rule:'(ŷ − 3)²'},
];
const gradientSymbols={z:'z',h:'h',prediction:String.raw`\hat y`};
const phaseLabel={init:'初始化',forward:'前向计算',backward:'反向求梯度',update:'更新参数',verify:'验证结果'};
export const FRAME_DELAY=4500;

function Value({value,active=false,emptyText="待计算"}:{value:number|undefined;active?:boolean;emptyText?:string}){
  return <strong key={value??'pending'} className={active?styles.arrive:undefined}>{value===undefined?<span className={styles.pending}>{emptyText}</span>:fmt(value,6)}</strong>;
}

function Graph({frame,index}:{frame:Frame;index:number}){
  const reverse=frame.phase==='backward';
  return <div className={styles.diagram} aria-label="前向结果和反向梯度">
    <div className={styles.rowHeading}><span>前向结果 <b>→</b></span><span>目标始终是 <strong>y = 3</strong></span></div>
    <div className={styles.nodes}>
      {nodes.map((node,i)=>{
        const active=frame.focus===node.key;
        const edge=frame.edge&&!reverse&&frame.edge[1]===node.key;
        return <div className={styles.node} key={node.key} data-active={active}>
          {i>0&&<span key={`${index}-edge`} className={styles.forwardArrow} data-flow={!!edge} aria-hidden="true">→</span>}
          <div className={styles.nodeLabel}>{node.label}</div><div className={styles.rule}>{node.rule}</div>
          <div className={styles.result} data-value={node.key}><i>{node.symbol}</i><span>=</span><Value value={frame.values[node.key]} active={active}/></div>
        </div>;
      })}
    </div>
    <div className={styles.gradients}>
      <div className={styles.gradientLegend}>反向求导 <b>←</b><small>沿同一条链<br/>从损失往回算</small></div>
      {(['z','h','prediction'] as const).map(key=>{
        const active=frame.focus===`grad-${key}`;
        const reused=key==='prediction'?['grad-w2','grad-b2','grad-h'].includes(frame.focus):key==='h'?frame.focus==='grad-z':['grad-w1','grad-b1'].includes(frame.focus);
        return <div className={styles.gradient} key={key} data-active={active} data-reused={reused} data-gradient={key}>
          <span key={`${index}-back`} className={styles.backwardArrow} data-flow={reverse&&frame.edge?.[1]===key} aria-hidden="true">←</span>
          <span className={styles.gradientDescription}>损失对 {key==='prediction'?'ŷ':key} 的偏导{reused&&<b>· 复用</b>}</span>
          <div className={styles.gradientValue}><Formula expression={partial(gradientSymbols[key])} symbols={[]}/><span>=</span><Value value={frame.gradients[key]} active={active} emptyText={frame.phase==='verify'?'本次不求导':'待计算'}/></div>
        </div>;
      })}
      <div className={styles.gradientEnd}>从 L 开始<small>每一段相乘<br/>就是链式法则</small></div>
    </div>
  </div>;
}

export function TrainingAnimation(){
  const stage=useRef<HTMLDivElement>(null);
  const [index,setIndex]=useState(0);
  const [playing,setPlaying]=useState(false);
  const frame=timeline[index];
  const last=index===timeline.length-1;
  useEffect(()=>{
    if(!playing||last)return;
    const timer=window.setTimeout(()=>setIndex(value=>Math.min(value+1,timeline.length-1)),FRAME_DELAY);
    return ()=>window.clearTimeout(timer);
  },[playing,index,last]);
  useEffect(()=>{if(last)setPlaying(false);},[last]);
  function bringIntoView(){
    const bounds=stage.current?.getBoundingClientRect();
    if(bounds&&(bounds.top<118||bounds.bottom>window.innerHeight))stage.current?.scrollIntoView?.({behavior:'smooth',block:'start'});
  }
  function seek(next:number){setPlaying(false);setIndex(Math.max(0,Math.min(next,timeline.length-1)));bringIntoView();}
  function play(){if(playing){setPlaying(false);return;}if(last)setIndex(0);setPlaying(true);bringIntoView();}
  return <div ref={stage} className={styles.animation} data-frame={index} data-focus={frame.focus} data-completed-rounds={frame.completed}>
    <div className={styles.toolbar}>
      <div className={styles.transport}>
        <button className={styles.play} onClick={play} aria-label={playing?'暂停动画':last?'重新播放':'播放动画'}><span aria-hidden="true">{playing?'Ⅱ':'▶'}</span>{playing?'暂停':last?'重播':'播放'}</button>
        <button onClick={()=>seek(index-1)} disabled={index===0}>上一步</button><button onClick={()=>seek(index+1)} disabled={last}>下一步</button>
        <button className={styles.reset} onClick={()=>seek(0)}>回到开始</button>
      </div>
      <span className={styles.round}>{frame.phase==='verify'?'两轮后验证':`第 ${frame.round} / 2 轮`}<span>η = 0.025</span></span>
    </div>
    <div className={styles.progress}>
      <span>{phaseLabel[frame.phase]}</span><input aria-label="动画进度" aria-valuetext={`第 ${index+1} 步：${frame.title}`} type="range" min="0" max={timeline.length-1} value={index} onChange={e=>seek(Number(e.target.value))}/><span>{index+1} / {timeline.length}</span>
    </div>
    <Graph frame={frame} index={index}/>
    <div className={styles.parameterHeader}><strong>{frame.phase==='verify'?'已更新两轮的参数':'可学习参数'}</strong><span>{frame.phase==='verify'?'本次只验证预测与损失':'先求齐四个梯度，再逐项算出新值'}</span></div>
    <div className={styles.parameters}>
      {parameterKeys.map(key=>{
        const active=frame.focus.endsWith(`-${key}`);
        return <div key={key} className={styles.parameter} data-active={active} data-parameter={key}>
          <div className={styles.parameterTop}><strong>{parameterNames[key]}</strong><span>{key.endsWith('1')?'第一层':'第二层'}{key.startsWith('w')?'权重':'偏置'}</span><b>{fmt(frame.params[key],6)}</b></div>
          <div className={styles.parameterGradient}><Formula expression={partial(parameterSymbols[key])} symbols={[]}/><span>=</span><span data-parameter-gradient={key}><Value value={frame.gradients[key]} active={frame.focus===`grad-${key}`} emptyText={frame.phase==='verify'?'本次不求导':'待计算'}/></span></div>
          <div className={styles.newValue} data-new-parameter={key}><span>新值 <b>→</b></span><Value value={frame.updates[key]} active={frame.focus===`update-${key}`} emptyText={frame.phase==='verify'?'不再更新':'待计算'}/></div>
        </div>;
      })}
    </div>
    <div className={styles.calculation} aria-live={playing?'off':'polite'}>
      <div className={styles.stepTitle}><span>{String(index+1).padStart(2,'0')}</span><h3>{frame.title}</h3></div>
      <div key={index} className={styles.equations}>
        <div><span className={styles.equationLabel}>计算关系</span><Formula expression={frame.formula} symbols={[]}/></div>
        <div className={styles.substitution}><span className={styles.equationLabel}>代入本轮数值</span><Formula expression={frame.substitution} symbols={[]}/></div>
      </div>
      <p>{frame.note}</p>
    </div>
    <div className={styles.footnote}>每步停留 4.5 秒；可暂停后单步查看。图中保留最多 6 位小数，公式最多 8 位；计算使用未舍入值。</div>
  </div>;
}
