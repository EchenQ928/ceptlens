import {evaluate,initial,learningRate,outputFirstKeys,parameterNames,parameterSymbols,trainingRounds,type Parameters} from './model';

export type NodeKey='x'|'z'|'h'|'prediction'|'loss';
export type GradientKey='z'|'h'|'prediction'|keyof Parameters;
export type Phase='init'|'forward'|'backward'|'update'|'verify';
export type Frame={
  round:number;phase:Phase;focus:string;title:string;note:string;formula:string;substitution:string;
  params:Parameters;values:Partial<Record<NodeKey,number>>;gradients:Partial<Record<GradientKey,number>>;
  updates:Partial<Parameters>;completed:number;edge?:[NodeKey,NodeKey];
};
const n=(v:number)=>Number(v.toFixed(8)).toString();
const operand=(v:number)=>v<0?`(${n(v)})`:n(v);
const parameterValues=(p:Parameters)=>String.raw`\begin{aligned}w_1&=${n(p.w1)},& b_1&=${n(p.b1)}\\w_2&=${n(p.w2)},& b_2&=${n(p.b2)}\end{aligned}`;
export const partial=(symbol:string)=>String.raw`\frac{\partial L}{\partial ${symbol}}`;
const dy=partial(String.raw`\hat y`),dh=partial('h'),dz=partial('z');
export const annotatedPrediction=String.raw`\hat y=w_2\,\underbrace{\operatorname{ReLU}\!\left(\underbrace{w_1x+b_1}_{z}\right)}_{h}+b_2`;

// Each frame is a complete immutable snapshot. Seeking never performs a training update.
export function buildTimeline():Frame[]{
  const frames:Frame[]=[];
  let frame:Frame={round:1,phase:'init',focus:'init',title:'从这组初始参数开始',note:'输入 x = 2，目标 y = 3。先做一次前向计算，再求梯度；此时还没有更新参数。',formula:annotatedPrediction,substitution:String.raw`(w_1,b_1,w_2,b_2)=(1,-1,2,0)`,params:{...initial},values:{},gradients:{},updates:{},completed:0};
  const push=(patch:Partial<Frame>)=>{frame={...frame,...patch,values:{...(patch.values??frame.values)},gradients:{...(patch.gradients??frame.gradients)},updates:{...(patch.updates??frame.updates)},params:{...(patch.params??frame.params)}};frames.push(frame);};
  push({});
  const rounds=trainingRounds(learningRate);
  function forward(params:Parameters,round:number,verify=false){
    const r=evaluate(params),phase=verify?'verify':'forward';
    push({round,phase,params,values:{x:2},gradients:{},updates:{},focus:'x',edge:undefined,title:verify?'用更新后的参数，再算一次预测':`第 ${round} 轮：输入 x = 2`,note:verify?'两轮参数更新已完成。接下来只验证预测和损失，不再更新。':round===1?'目标 y = 3 保持固定。沿箭头，把输入送入第一层。':'换用上一轮的新参数。所有中间值和梯度都要重新计算。',formula:String.raw`x=2,\quad y=3`,substitution:parameterValues(params)});
    push({focus:'z',edge:['x','z'],values:{...frame.values,z:r.z},title:'第一层：乘权重，再加偏置',note:'把这个中间结果记作 z，送给激活函数。',formula:'z=w_1x+b_1',substitution:String.raw`z=${operand(params.w1)}\times 2+${operand(params.b1)}=${n(r.z)}`});
    push({focus:'h',edge:['z','h'],values:{...frame.values,h:r.h},title:'激活函数：得到 h',note:'本例 z > 0，ReLU 保留原值。h 就是第一层传给第二层的结果。',formula:String.raw`h=\operatorname{ReLU}(z)=\max(0,z)`,substitution:String.raw`h=\max(0,${n(r.z)})=${n(r.h)}`});
    push({focus:'prediction',edge:['h','prediction'],values:{...frame.values,prediction:r.prediction},title:'第二层：得到预测 ŷ',note:'第二层用自己的权重 w₂ 和偏置 b₂，组合输入 h。',formula:String.raw`\hat y=w_2h+b_2`,substitution:String.raw`\hat y=${operand(params.w2)}\times ${operand(r.h)}+${operand(params.b2)}${Math.abs(Number(n(r.prediction))-r.prediction)>1e-10?String.raw`\approx`:"="} ${n(r.prediction)}`});
    push({focus:'loss',edge:['prediction','loss'],values:{...frame.values,loss:r.loss},title:verify?'验证完成：两轮更新后的损失':'用预测与目标，计算损失',note:verify?'损失从 1 降到约 0.000678。可以回看任意一步，核对每个数的来源。':'此时参数仍未改变。接下来求这个损失对每个参数的偏导。',formula:String.raw`L=(\hat y-y)^2`,substitution:String.raw`L=(${n(r.prediction)}-3)^2\approx ${n(r.loss)}`});
  }
  for(let i=0;i<rounds.length;i++){
    const {params,before:r,next}=rounds[i];
    forward(params,i+1);
    const grad=(key:GradientKey,value:number,patch:Partial<Frame>)=>push({phase:'backward',focus:`grad-${key}`,edge:undefined,gradients:{...frame.gradients,[key]:value},...patch});
    grad('prediction',r.predictionGradient,{edge:['loss','prediction'],title:'先求损失对预测的偏导',note:'平方求导后得到 2(ŷ − y)。代入这一轮的预测和目标，得到一个具体的梯度数值。',formula:String.raw`${dy}=2(\hat y-y)`,substitution:String.raw`${dy}=2\times(${n(r.prediction)}-3)=${n(r.predictionGradient)}`});
    grad('w2',r.gradients.w2,{title:'第二层权重 w₂：沿 w₂ → ŷ → L 求导',note:'链式法则：已知的损失对预测的偏导，乘上预测对 w₂ 的偏导 h。',formula:String.raw`${partial('w_2')}=\underbrace{${dy}}_{\text{已算出}}\cdot\underbrace{\frac{\partial\hat y}{\partial w_2}}_{h}`,substitution:String.raw`${partial('w_2')}=${operand(r.predictionGradient)}\times ${operand(r.h)}=${n(r.gradients.w2)}`});
    grad('b2',r.gradients.b2,{title:'第二层偏置 b₂：复用同一个偏导',note:'ŷ = w₂h + b₂ 对 b₂ 的偏导是 1。仍然使用右上方保存的 ∂L/∂ŷ。',formula:String.raw`${partial('b_2')}=\underbrace{${dy}}_{\text{已算出}}\cdot\underbrace{\frac{\partial\hat y}{\partial b_2}}_{1}`,substitution:String.raw`${partial('b_2')}=${operand(r.predictionGradient)}\times1=${n(r.gradients.b2)}`});
    grad('h',r.hGradient,{edge:['prediction','h'],title:'继续向前：求损失对 h 的偏导',note:'h 通过第二层影响预测。把已算出的 ∂L/∂ŷ 乘上这一层的权重 w₂。',formula:String.raw`${dh}=\underbrace{${dy}}_{\text{已算出}}\cdot\underbrace{\frac{\partial\hat y}{\partial h}}_{w_2}`,substitution:String.raw`${dh}=${operand(r.predictionGradient)}\times ${operand(params.w2)}=${n(r.hGradient)}`});
    grad('z',r.zGradient,{edge:['h','z'],title:'穿过 ReLU：求损失对 z 的偏导',note:'本轮 z > 0，ReLU 在这里的导数为 1。这个结果将被第一层的两个参数共用。',formula:String.raw`${dz}=\underbrace{${dh}}_{\text{已算出}}\cdot\underbrace{\frac{\partial h}{\partial z}}_{\operatorname{ReLU}'(z)}`,substitution:String.raw`${dz}=${operand(r.hGradient)}\times 1=${n(r.zGradient)}`});
    grad('w1',r.gradients.w1,{title:'第一层权重 w₁：复用 ∂L/∂z',note:'z = w₁x + b₁ 对 w₁ 的偏导是 x。前面那一段链路已经包含在 ∂L/∂z 里，不必重算。',formula:String.raw`${partial('w_1')}=\underbrace{${dz}}_{\text{已算出}}\cdot\underbrace{\frac{\partial z}{\partial w_1}}_{x}`,substitution:String.raw`${partial('w_1')}=${operand(r.zGradient)}\times 2=${n(r.gradients.w1)}`});
    grad('b1',r.gradients.b1,{title:'第一层偏置 b₁：四个参数的梯度齐了',note:'z 对 b₁ 的偏导是 1。到这里完成反向传播，下面才开始计算参数的新值。',formula:String.raw`${partial('b_1')}=\underbrace{${dz}}_{\text{已算出}}\cdot\underbrace{\frac{\partial z}{\partial b_1}}_{1}`,substitution:String.raw`${partial('b_1')}=${operand(r.zGradient)}\times 1=${n(r.gradients.b1)}`});
    for(const key of outputFirstKeys){
      const symbol=parameterSymbols[key];
      push({phase:'update',focus:`update-${key}`,edge:undefined,updates:{...frame.updates,[key]:next[key]},title:`计算 ${parameterNames[key]} 的新值`,note:'学习率 η = 0.025 在这一步乘上梯度。本轮四项更新都使用同一次反向传播得到的梯度。',formula:String.raw`${symbol}^{\mathrm{new}}=${symbol}^{\mathrm{old}}-\underbrace{0.025}_{\text{学习率 }\eta}\cdot ${partial(symbol)}`,substitution:String.raw`${symbol}^{\mathrm{new}}=${operand(params[key])}-0.025\times ${operand(r.gradients[key])}=${n(next[key])}`});
    }
    push({focus:'commit',completed:i+1,title:`第 ${i+1} 轮更新完成`,note:i===0?'四个新值都已准备好。下一步换用这组参数，重新前向计算。':'四个新值都已准备好。接下来做一次前向验证，看看预测和损失。',formula:String.raw`\theta_{\mathrm{new}}=\theta_{\mathrm{old}}-0.025\,\nabla_\theta L`,substitution:parameterValues(next)});
  }
  forward(rounds[1].next,2,true);
  return frames;
}
export const timeline=buildTimeline();
