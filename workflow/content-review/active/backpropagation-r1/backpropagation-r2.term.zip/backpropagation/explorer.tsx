import {useEffect,useRef,useState} from 'react';
import {after,example,fmt,initial,learningRate,parameterKeys,parameterNames,probeChange,probes,signed,stages,updated,valueNames,type Parameters,type ProbeName} from './model';
import styles from './styles.module.css';

function Network({stage,applied}:{stage:number;applied:boolean}) {
  const params=applied?updated:initial, values=applied?after:example;
  const focus=stage===1?'loss':stage===2?'output':stage===3?'activation':stage===4?'hidden':'';
  const node=(id:string,x:number,width:number,title:string,rule:string)=><g data-node={id} data-selected={focus===id}><rect className={focus===id?styles.selectedNode:styles.node} x={x} y="52" width={width} height="68" rx="4"/><text className={styles.nodeTitle} x={x+width/2} y="78">{title}</text><text className={styles.nodeRule} x={x+width/2} y="104">{rule}</text></g>;
  const edge=(from:number,to:number,label:string)=><g><path className={styles.forwardLine} d={`M${from} 86 H${to} m-6 -4 l6 4 l-6 4`}/><text className={styles.edgeValue} x={(from+to)/2} y="69">{label}</text></g>;
  return <div className={styles.network}>
    <div className={styles.graphHeading}><strong>{applied?'更新后：用新参数重新计算':'前向计算：从输入得到预测和损失'}</strong><span>{applied?'四个参数已同时更新':'输入与目标固定，下面四个参数等待更新'}</span></div>
    <svg className={styles.graph} viewBox="0 0 1060 215" role="img" aria-label={`输入2，第一层结果${fmt(values.z)}，ReLU结果${fmt(values.h)}，预测${fmt(values.prediction)}，目标3，平方损失${fmt(values.loss)}`}>
      <text className={styles.input} x="42" y="94">x = 2</text>
      {edge(80,112,'')}{node('hidden',112,136,'第一层','w₁x + b₁')}{edge(248,361,`z = ${fmt(values.z)}`)}
      {node('activation',361,96,'ReLU','负数归零')}{edge(457,567,`h = ${fmt(values.h)}`)}
      {node('output',567,136,'第二层','w₂h + b₂')}{edge(703,836,`ŷ = ${fmt(values.prediction)}`)}
      {node('loss',836,126,'平方损失','(ŷ − y)²')}{edge(962,1000,'')}<text className={styles.finalValue} x="1018" y="83">L</text><text className={styles.finalValue} data-forward-loss x="1018" y="110">{fmt(values.loss)}</text>
      <text className={styles.parameter} x="180" y="153">权重 w₁ = {fmt(params.w1)}</text><text className={styles.parameter} x="180" y="181">偏置 b₁ = {fmt(params.b1)}</text>
      <text className={styles.parameter} x="635" y="153">权重 w₂ = {fmt(params.w2)}</text><text className={styles.parameter} x="635" y="181">偏置 b₂ = {fmt(params.b2)}</text>
      <text className={styles.targetLabel} x="899" y="23">目标 y = 3</text><path className={styles.forwardLine} d="M899 29 V48 m-4 -6 l4 6 l4 -6"/>
    </svg>
  </div>;
}

function PredictionPosition({prediction}:{prediction:number}) {
  const px=(n:number)=>55+(n-1)*180;
  return <svg className={styles.position} viewBox="0 0 520 115" role="img" aria-label={`预测${fmt(prediction)}，目标3；横轴为预测值`}>
    <text x="25" y="18" className={styles.axisLabel}>预测值</text>
    <line x1="55" x2="490" y1="56" y2="56" className={styles.forwardLine}/>
    {[1,2,3].map(n=><g key={n}><line x1={px(n)} x2={px(n)} y1="51" y2="61" className={styles.forwardLine}/><text className={styles.tick} x={px(n)} y="83">{n}</text></g>)}
    <path d={`M${px(3)} 31 V93`} className={styles.targetLine}/><text x={px(3)} y="108" className={styles.targetLabel}>目标 3</text>
    <circle cx={px(prediction)} cy="56" r="6" className={styles.point}/><text x={px(prediction)} y="37" className={styles.positionLabel}>预测 {fmt(prediction)}</text>
  </svg>;
}

function Influence({name,delta}:{name:ProbeName;delta:number}) {
  const {definition:d,result,gradient,estimatedLossDelta,actualLossDelta,ratio}=probeChange(name,delta);
  const isPrediction=name==='prediction';
  return <div className={styles.influence} data-probe={name}>
    <div className={styles.changePath} data-count={isPrediction?2:3}>
      <div><span>{d.label}</span><strong>{fmt(d.value)} <i>→</i> {fmt(d.value+delta)}</strong><b>变化 {signed(delta)}</b></div>
      <div className={styles.pathArrow}><span>{isPrediction?'代入平方损失':`变化 × ${d.local}`}</span><b>→</b></div>
      {!isPrediction&&<><div><span>{valueNames[d.next]}</span><strong>{fmt(example[d.next])} <i>→</i> {fmt(result[d.next])}</strong><b>变化 {signed(result[d.next]-example[d.next])}</b></div><div className={styles.pathArrow}><span>再影响损失</span><b>→</b></div></>}
      <div className={styles.lossTile}><span>平方损失 L</span><strong>1 <i>→</i> <b data-probe-loss>{fmt(result.loss)}</b></strong><b>实际变化 {signed(actualLossDelta)}</b></div>
    </div>
    {isPrediction?<>
      <p>预测{delta>0?'增大':'减小'} {fmt(Math.abs(delta))}，损失{actualLossDelta<0?'减少':'增加'} {fmt(Math.abs(actualLossDelta))}。两者的变化量相除：</p>
      <div className={styles.ratio}><span>损失变化 ÷ 预测变化</span><strong>{signed(actualLossDelta)} ÷ ({signed(delta)}) = <b data-ratio>{fmt(ratio)}</b></strong></div>
      <p>把试改量缩得越来越小，这个比值会趋近 <strong>−2</strong>。这个数叫<strong>损失对预测的梯度</strong>：在预测为 2 附近，预测增加很小一点，损失大约减少它的 2 倍。</p>
      <div className={styles.gradientConclusion}><span>平方损失的求导规则：2 ×（预测 − 目标）</span><strong>2 × (2 − 3) = −2</strong></div>
      <p className={styles.note}>实际反向传播直接用求导规则算出 −2。这里的试改用于看懂它的含义，不是训练时逐个试改预测。</p>
    </>:<>
      <p>{d.reason}</p>
      <div className={styles.known}><strong>后面的影响已经知道：</strong>{valueNames[d.next]}变化 × ({fmt(d.downstream)}) ≈ 损失变化。</div>
      <div className={styles.combine}><div><span>{d.label}对{valueNames[d.next]}的影响</span><strong>{fmt(d.local)}</strong></div><b>×</b><div><span>{valueNames[d.next]}对损失的影响</span><strong>{fmt(d.downstream)}</strong></div><b>=</b><div><span>{d.label}的梯度</span><strong data-probe-gradient>{fmt(gradient)}</strong></div></div>
      <p className={styles.estimate}>本次试改，预计损失变化约为 <strong>{signed(delta)} × ({fmt(gradient)}) = {signed(estimatedLossDelta)}</strong>；上图实际重算为 <strong>{signed(actualLossDelta)}</strong>。梯度描述很小变化的影响，所以有限幅度的试改会有近似误差。</p>
    </>}
  </div>;
}

export function BackpropExplorer() {
  const [selected,setSelected]=useState(0);
  const [choice,setChoice]=useState<ProbeName>('b2');
  const [direction,setDirection]=useState(1);
  const [amount,setAmount]=useState(.01);
  const [applied,setApplied]=useState(false);
  const panel=useRef<HTMLDivElement>(null);
  const previousFocus=useRef(`${selected}:${choice}`);
  useEffect(()=>{
    const focus=`${selected}:${choice}`;
    if(previousFocus.current===focus)return;
    previousFocus.current=focus;
    panel.current?.scrollIntoView?.({behavior:window.matchMedia?.('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});
  },[selected,choice]);
  const step=stages[selected];
  const chooseStep=(index:number)=>{setSelected(index);setChoice(index===4?'w1':'b2');setDirection(1);setAmount(.01);setApplied(false);};
  const name:ProbeName=selected===1?'prediction':selected===3?'z':choice;
  const currentParams=applied?updated:initial;
  const learned=(key:keyof Parameters)=>selected>=5||(key==='b2'&&selected>=2)||(key==='w2'&&(selected>2||selected===2&&choice!=='b2'))||(key==='w1'&&selected===4)||(key==='b1'&&selected===4&&choice==='b1');
  const nextChoice:ProbeName|null=selected===2?(choice==='b2'?'w2':choice==='w2'?'h':null):selected===4&&choice==='w1'?'b1':null;
  return <div className={styles.explorer}>
    <nav className={styles.stepButtons} aria-label="演示步骤">{stages.map((item,i)=><button key={item.id} aria-pressed={i===selected} onClick={()=>chooseStep(i)}><small>{String(i+1).padStart(2,'0')}</small>{item.label}</button>)}</nav>
    <Network stage={selected} applied={applied}/>
    <div className={styles.stageBody} ref={panel} data-current-step={step.id}>
      <div className={styles.stageHeading}><span>{selected===0?'前向计算':selected===5?'参数更新':'反向追踪'}</span><h3>{step.title}</h3></div>
      {selected===0?<>
        <div className={styles.startGrid}><div><p>输入 <strong>x = 2</strong>，希望网络输出 <strong>3</strong>。这组演示参数却算出 <strong>2</strong>，平方损失为 <strong>1</strong>。</p><p>训练要调整的是图中的<strong>两个权重、两个偏置</strong>。先弄清每个参数对损失的影响，才能决定怎样改。</p></div><PredictionPosition prediction={2}/></div>
        <div className={styles.route}><span>先判断预测怎样影响损失</span><b>→</b><span>沿计算关系追到每个参数</span><b>→</b><span>统一更新，再算一次</span></div>
        <p className={styles.note}>这是一个样本的完整训练步骤。输入、目标和初始参数均为手工设置；点击“下一步”逐段查看。</p>
      </>:selected===5?<>
        <p>本例四个梯度都是负数，说明这些参数在当前位置略微增大，损失会下降。采用最简单的梯度下降：<strong>新参数 = 原参数 − 学习率 × 梯度</strong>。学习率取 <strong>{learningRate}</strong>，控制这一步的大小。</p>
        <table className={styles.updateTable}><thead><tr><th>参数</th><th>本次梯度</th><th>更新计算</th><th>当前值</th></tr></thead><tbody>{parameterKeys.map(key=><tr key={key}><th>{key.startsWith('w')?'权重':'偏置'} {parameterNames[key]}</th><td>{fmt(example.gradients[key])}</td><td>{fmt(initial[key])} − 0.025 × ({fmt(example.gradients[key])}) = <strong>{fmt(updated[key])}</strong></td><td data-parameter={key}>{fmt(currentParams[key])}</td></tr>)}</tbody></table>
        <div className={styles.applyRow}><button className={styles.primary} onClick={()=>setApplied(true)} disabled={applied}>{applied?'已完成这一次更新':'同时更新四个参数'}</button><button onClick={()=>setApplied(false)} disabled={!applied}>恢复更新前</button><span>四个梯度都来自同一次前向计算。</span></div>
        <div className={styles.verification} aria-live="polite" data-applied={applied}>
          <PredictionPosition prediction={applied?after.prediction:example.prediction}/>
          <div><span>{applied?'新参数重新算出的预测':'更新前的预测'}</span><strong data-current-prediction>{fmt(applied?after.prediction:example.prediction)}</strong><span>目标始终为 3</span></div>
          <div><span>{applied?'更新后的平方损失':'更新前的平方损失'}</span><strong data-current-loss>{fmt(applied?after.loss:example.loss)}</strong><span>{applied?'原损失为 1，这一步明显降低':'等待执行参数更新'}</span></div>
        </div>
        <p>{applied?'预测从 2 变成 3.125，略微越过了目标，但比原来更接近 3。接下来会用这组新参数重新计算梯度，再更新。':'反向传播算出梯度时，参数仍保持原值。点击上方按钮后，参数、前向图和损失才一起变化。'}</p>
        <p className={styles.note}>负梯度不意味着参数永远该增大；换了参数或样本，方向也可能改变。学习率过大还可能使损失上升。</p>
      </>:<>
        {selected===1&&<p>目标是 3，预测 2 偏低。先把预测轻轻推向目标，看看损失到底减少了多少。</p>}
        {selected===2&&<><p>第二层计算 <strong>ŷ = w₂ × h + b₂</strong>。它的权重、偏置和输入 h 都能影响预测。逐个查看，另外两个量保持原值。</p><div className={styles.objectButtons}>{(['b2','w2','h'] as const).map(key=><button key={key} aria-pressed={choice===key} onClick={()=>setChoice(key)}>{probes[key].label}</button>)}</div></>}
        {selected===3&&<p>上一层的结果 <strong>z</strong> 经过 ReLU 得到 <strong>h</strong>。刚才已经算出：<strong>h 变化 × (−4) ≈ 损失变化</strong>。现在看 z 改变时，这个影响怎样继续传回去。</p>}
        {selected===4&&<><p>第一层计算 <strong>z = w₁ × x + b₁</strong>，输入 <strong>x = 2</strong>。上一步已经得到 z 的梯度 <strong>−4</strong>，用它继续求两个参数的影响。</p><div className={styles.objectButtons}>{(['w1','b1'] as const).map(key=><button key={key} aria-pressed={choice===key} onClick={()=>setChoice(key)}>{probes[key].label}</button>)}</div></>}
        <div className={styles.probeControls}><strong>只试改{probes[name].label}</strong><div>{[1,-1].map(sign=><button key={sign} aria-pressed={direction===sign} onClick={()=>setDirection(sign)}>{sign===1?'增加':'减少'} {fmt(amount)}</button>)}</div>{selected===1&&<label>试改量<select aria-label="试改量" value={amount} onChange={e=>setAmount(Number(e.target.value))}>{[.01,.001,.0001].map(v=><option key={v} value={v}>{v}</option>)}</select></label>}</div>
        <Influence name={name} delta={direction*amount}/>
        {(name==='h'||name==='z')&&<p className={styles.intermediateNote}><strong>{name} 是中间结果，不是待更新的参数。</strong>这里暂时单独改变它，是为了看清它的影响；真正改变它，要继续追到生成它的那一层参数。</p>}
        {selected===3&&<details className={styles.forwardDetails}><summary>如果 ReLU 的输入小于 0 呢？</summary><p>例如 z = −1 时，ReLU 输出为 0。把 z 改到 −0.99，输出仍为 0，后面也不变。这一小段的影响系数为 0，因此这条路径传到 z 的梯度为 0。恰好在 0 处不可导，PyTorch 约定取 0。</p></details>}
        {selected>=2&&<div className={styles.gradientRecord}><strong>本轮参数梯度 <small>记录影响，尚未更新参数</small></strong><div>{parameterKeys.map(key=><div key={key} data-gradient={key}><span>{parameterNames[key]}</span><b>{learned(key)?fmt(example.gradients[key]):'待计算'}</b></div>)}</div></div>}
      </>}
    </div>
    <div className={styles.navigation}><button disabled={selected===0} onClick={()=>chooseStep(selected-1)}>上一步</button><span>{selected+1} / {stages.length}</span>{selected<5?<button className={styles.primary} onClick={()=>{if(nextChoice){setChoice(nextChoice);setDirection(1);}else chooseStep(selected+1);}}>{nextChoice?`接着看：${probes[nextChoice].label}`:`下一步：${stages[selected+1].label}`}</button>:<button onClick={()=>chooseStep(0)}>从头再看</button>}</div>
  </div>;
}
