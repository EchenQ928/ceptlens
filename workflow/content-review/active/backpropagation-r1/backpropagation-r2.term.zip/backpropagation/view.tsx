import {Callout,CodeBlock,Formula,Paragraph,TermSection,defineTermView} from '@term-sdk';
import {BackpropExplorer} from './explorer';
import {learningRate} from './model';
import {backwardCode,updateCode} from './pytorch';
import styles from './styles.module.css';

function TermBody() {
  return <div className={styles.root}>
    <TermSection id="influence" title="预测错了，怎样找到该调整的参数？">
      <Paragraph>{'模型预测偏离目标，损失函数会给出一个分数。但训练能修改的是权重和偏置。反向传播沿着产生预测的计算关系，从损失往前追，算清每个参数稍微改变时，损失会受到怎样的影响。'}</Paragraph>
      <p>这个影响用<strong>梯度</strong>表示。先跟着一个小网络看完它的具体含义，再看数学公式。</p>
    </TermSection>
    <TermSection id="walk" title="跟着一个小网络，完成一次训练">
      <Paragraph>{'这个网络有两层，第一层后接 ReLU 激活，最后用平方误差计分。演示会依次展开：先算预测，再追踪影响，最后同时更新权重和偏置。'}</Paragraph>
      <BackpropExplorer />
    </TermSection>
    <TermSection id="chain" title="回头看：为什么叫“反向传播”">
      <Paragraph>{'数值的计算顺序是：参数影响中间结果，中间结果影响预测，预测决定损失。要算参数的影响，我们反过来处理：先弄清预测对损失的影响，再利用这个结果，逐层往前求。回传的是“对损失的影响”，不是把预测值倒着算回来。'}</Paragraph>
      <p>以第一层权重 w₁ 为例：它的一点变化，先被输入 <strong>2</strong> 放大，经过 ReLU 保留，再被第二层权重 <strong>2</strong> 放大，最后按预测梯度 <strong>−2</strong> 影响损失。连起来就是 <strong>2 × 1 × 2 × (−2) = −8</strong>。把沿途的影响系数相乘，这就是<strong>链式法则</strong>。</p>
      <details className={styles.forwardDetails}><summary>把这条关系写成求导公式</summary>
      <Formula expression={String.raw`\frac{\partial L}{\partial w_1}=\underbrace{\frac{\partial L}{\partial\hat y}}_{-2}\cdot\underbrace{\frac{\partial\hat y}{\partial h}}_{2}\cdot\underbrace{\frac{\partial h}{\partial z}}_{1}\cdot\underbrace{\frac{\partial z}{\partial w_1}}_{2}=-8`} symbols={[{symbol:String.raw`\frac{\partial L}{\partial w_1}`,meaning:'损失对第一层权重的梯度。符号表示其他独立量固定时，w₁ 的局部影响。'},{symbol:String.raw`\hat y,h,z`,meaning:'依次对应图中的预测、激活结果、第一层加权结果。'},{symbol:'L',meaning:'这次前向得到的平方损失。'}]} />
      </details>
      <Paragraph>{'反向传播按这个顺序复用已经算出的梯度，不必为每个参数单独重算整条路径。前向的中间结果也会派上用场，例如第二层权重的梯度就用到了 h = 1。'}</Paragraph>
      <Paragraph>{'一批样本共同训练时，通常先分别计分，再取平均。每个参数的梯度也综合这一批样本的影响；因此更新并不一定让每个样本的损失都降低。'}</Paragraph>
      <details className={styles.forwardDetails}><summary>如果一个量影响了多条路径呢？</summary><Paragraph>{'各条路径的影响需要相加。举一个额外的小例子：同一个 h 同时进入两项损失，第一项是 (2h − 3)²，第二项是 h²。在 h = 1 时，两条路径传回的梯度分别为 −4 和 +2，总影响就是 −2。'}</Paragraph><Formula expression={String.raw`L=L_a+L_b\quad\Longrightarrow\quad\frac{\partial L}{\partial h}=\frac{\partial L_a}{\partial h}+\frac{\partial L_b}{\partial h}=-4+2=-2`} symbols={[{symbol:'L_a,L_b',meaning:'两条路径上的损失，分别为 (2h−3)² 和 h²。'},{symbol:'h',meaning:'被两条路径共同使用的量；本例取 1。'}]} /><Paragraph>{'所以，同一条路径上按链式法则相乘，多条路径汇合时把梯度相加。'}</Paragraph></details>
    </TermSection>
    <TermSection id="pytorch" title="在 PyTorch 中复现">
      <Paragraph>{'PyTorch 会在前向时记录需要求导的运算关系。对损失调用 backward()，就会自动按这些关系反向计算，并把参数梯度存入 .grad。'}</Paragraph>
      <CodeBlock language="python" code={backwardCode} caption="requires_grad=True 表示需要跟踪这个参数的梯度。四个变量与图中的 w₁、b₁、w₂、b₂ 一一对应。" />
      <details className={styles.forwardDetails}><summary>接着执行一次参数更新</summary><CodeBlock language="python" code={updateCode} caption={`使用普通 SGD，学习率 ${learningRate}；与上面的参数对照表一致。`} /></details>
      <Paragraph>{'backward() 只计算梯度，optimizer.step() 才修改参数。PyTorch 默认累加梯度，因此每轮开始通常用 zero_grad() 清空上一轮的结果。'}</Paragraph>
      <Callout tone="key" title="总结">{'前向算出预测、损失和中间结果；反向沿计算关系，把局部影响逐步乘起来，遇到多条路径再相加，得到参数梯度；优化器随后使用梯度更新参数。'}</Callout>
      <p className={styles.source}>参考：<a href="https://docs.pytorch.org/tutorials/beginner/basics/autogradqs_tutorial.html" target="_blank" rel="noreferrer">PyTorch · 自动微分</a><a href="https://www.3blue1brown.com/lessons/backpropagation/" target="_blank" rel="noreferrer">3Blue1Brown · 反向传播直觉</a><a href="https://cs231n.github.io/optimization-2/" target="_blank" rel="noreferrer">Stanford CS231n · 计算图与链式法则</a></p>
    </TermSection>
  </div>;
}
export default defineTermView({termId:'backpropagation',Component:TermBody});
