export const fmt = (value:number, digits=8) => String(Number(value.toFixed(digits))).replace('-','−');
export type Parameters = {w1:number;b1:number;w2:number;b2:number};
export const initial:Parameters={w1:1,b1:-1,w2:2,b2:0};
export function evaluate(params:Parameters, x=2, target=3) {
  const z=params.w1*x+params.b1;
  const h=Math.max(0,z);
  const prediction=params.w2*h+params.b2;
  const loss=(prediction-target)**2;
  const predictionGradient=2*(prediction-target);
  const hGradient=predictionGradient*params.w2;
  const zGradient=hGradient*(z>0?1:0);
  const gradients={w1:zGradient*x,b1:zGradient,w2:predictionGradient*h,b2:predictionGradient};
  return {z,h,prediction,loss,predictionGradient,hGradient,zGradient,gradients};
}
export const example=evaluate(initial);
export const learningRate=0.025;
export const updated=Object.fromEntries(Object.entries(initial).map(([name,value])=>[name,value-learningRate*example.gradients[name as keyof Parameters]])) as Parameters;
export const after=evaluate(updated);
export const parameterNames:Record<keyof Parameters,string>={w1:'w₁',b1:'b₁',w2:'w₂',b2:'b₂'};
export const parameterKeys = ['w1','b1','w2','b2'] as const;
export const signed = (value:number) => value>0 ? `+${fmt(value)}` : fmt(value);
export const stages = [
  {id:'forward',label:'算出预测',title:'预测是 2，目标是 3。能改的是哪些数？'},
  {id:'prediction',label:'从损失开始',title:'先看：预测增加一点，损失怎样变？'},
  {id:'output',label:'找到第二层',title:'预测由第二层算出。谁能影响它？'},
  {id:'activation',label:'经过 ReLU',title:'继续往前：h 又是怎样得到的？'},
  {id:'hidden',label:'找到第一层',title:'现在，可以追到第一层的权重和偏置了。'},
  {id:'update',label:'更新并验证',title:'四个参数的影响都算清了，一起更新。'},
];
export type ProbeName = 'prediction'|'b2'|'w2'|'h'|'z'|'w1'|'b1';
type ProbeDefinition = {label:string;value:number;next:'prediction'|'h'|'z';local:number;downstream:number;reason:string};
export const probes:Record<ProbeName,ProbeDefinition> = {
  prediction:{label:'预测 ŷ',value:example.prediction,next:'prediction',local:1,downstream:example.predictionGradient,reason:''},
  b2:{label:'第二层偏置 b₂',value:initial.b2,next:'prediction',local:1,downstream:example.predictionGradient,reason:'偏置直接加到预测上，增加多少，预测就增加多少。'},
  w2:{label:'第二层权重 w₂',value:initial.w2,next:'prediction',local:example.h,downstream:example.predictionGradient,reason:'权重乘的是 h = 1。因此，权重的变化乘以 1，就是预测的变化。'},
  h:{label:'中间结果 h',value:example.h,next:'prediction',local:initial.w2,downstream:example.predictionGradient,reason:'h 要乘权重 w₂ = 2。因此，h 的变化会被放大 2 倍，再影响预测。'},
  z:{label:'第一层结果 z',value:example.z,next:'h',local:1,downstream:example.hGradient,reason:'这里 z = 1，大于 0；附近的数经过 ReLU 后保持原值，所以 h 跟着改变同样多。'},
  w1:{label:'第一层权重 w₁',value:initial.w1,next:'z',local:2,downstream:example.zGradient,reason:'权重乘的是输入 x = 2。因此，权重的变化乘以 2，就是 z 的变化。'},
  b1:{label:'第一层偏置 b₁',value:initial.b1,next:'z',local:1,downstream:example.zGradient,reason:'偏置直接加到第一层结果上，增加多少，z 就增加多少。'},
};
export const valueNames = {prediction:'预测 ŷ',h:'激活结果 h',z:'第一层结果 z'};
// Pedagogical intervention only. Backpropagation itself uses the analytic gradients above.
export function probeChange(name:ProbeName,delta:number) {
  const definition=probes[name];
  let result:ReturnType<typeof evaluate>;
  if(parameterKeys.some(key=>key===name)) result=evaluate({...initial,[name]:definition.value+delta});
  else {
    const z=example.z+(name==='z'?delta:0);
    const h=Math.max(0,z)+(name==='h'?delta:0);
    const prediction=initial.w2*h+initial.b2+(name==='prediction'?delta:0);
    result={...example,z,h,prediction,loss:(prediction-3)**2};
  }
  const gradient=definition.local*definition.downstream;
  return {definition,result,delta,gradient,estimatedLossDelta:gradient*delta,actualLossDelta:result.loss-example.loss,ratio:(result.loss-example.loss)/delta};
}
