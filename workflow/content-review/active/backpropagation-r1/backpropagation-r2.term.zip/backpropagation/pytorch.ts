export const backwardCode = `import torch

# 对应图中的输入、目标，以及两层的四个参数
x, target = torch.tensor(2.0), torch.tensor(3.0)
w1 = torch.tensor(1.0, requires_grad=True)
b1 = torch.tensor(-1.0, requires_grad=True)
w2 = torch.tensor(2.0, requires_grad=True)
b2 = torch.tensor(0.0, requires_grad=True)
parameters = [w1, b1, w2, b2]
optimizer = torch.optim.SGD(parameters, lr=0.025)

optimizer.zero_grad()  # 清空此前累积的梯度

# 前向：记录运算关系，算出中间值、预测与损失
z = w1 * x + b1
h = torch.relu(z)
prediction = w2 * h + b2
loss = (prediction - target).square()

loss.backward()  # 反向：沿记录的运算关系计算各参数的梯度
print(loss.item())  # 1.0
print([p.grad.item() for p in parameters])  # [-8.0, -4.0, -2.0, -2.0]
# 此时四个参数仍是原值；梯度保存在各自的 .grad 中`;

export const updateCode = `# 接着上面的代码：现在才执行一次参数更新
optimizer.step()
print([round(p.item(), 3) for p in parameters])
# [1.2, -0.9, 2.05, 0.05]

with torch.no_grad():  # 仅检查新参数的预测，不再构建求导记录
    new_z = w1 * x + b1
    new_h = torch.relu(new_z)
    new_prediction = w2 * new_h + b2
    new_loss = (new_prediction - target).square()

print(round(new_prediction.item(), 3))  # 3.125
print(round(new_loss.item(), 6))        # 0.015625`;
