import {useState} from 'react';
import {example,fmt,initial,parameterNames,steps,type Parameters} from './model';
import styles from './styles.module.css';

export function BackpropExplorer() {
  const [selected,setSelected]=useState(0);
  const step=steps[selected];
  const node=(id:string,x:number,width:number,title:string,rule:string)=><g data-node={id} data-selected={step.id===id}><rect className={step.id===id?styles.selectedNode:styles.node} x={x} y="65" width={width} height="64" rx="4"/><text className={styles.nodeTitle} x={x+width/2} y="89">{title}</text><text className={styles.nodeRule} x={x+width/2} y="115">{rule}</text></g>;
  const forward=(from:number,to:number,value:string)=><g><path className={styles.forwardLine} d={`M${from} 97 H${to} m-6 -4 l6 4 l-6 4`}/><text className={styles.edgeValue} x={(from+to)/2} y="81">{value}</text></g>;
  const backward=(from:number,to:number,label:string,id:string)=><g data-backward={id} data-selected={step.id===id}><path className={step.id===id?styles.activeBackward:styles.backwardLine} d={`M${from} 224 H${to} m6 -4 l-6 4 l6 4`}/><text className={styles.gradientLabel} x={(from+to)/2} y="211">{label}</text></g>;
  return <div className={styles.explorer}>
    <div className={styles.graphHeading}><strong>同一个网络：上面算数值，下面传梯度</strong><p>输入 x = 2，目标 y = 3。参数为固定演示值；选择步骤只改变讲解位置。</p></div>
    <svg className={styles.graph} viewBox="0 0 1000 260" role="img" aria-label="前向：2 经过第一层得到1，ReLU得到1，第二层得到预测2，平方损失为1。反向：从损失开始，预测梯度负2，h梯度负4，z梯度负4，最后得到四个参数的梯度。">
      <text className={styles.laneLabel} x="22" y="28">前向 → 数值</text><text className={styles.input} x="40" y="105">x = 2</text>
      {forward(80,120,'')}{node('hidden',120,120,'第一层','w₁x + b₁')}{forward(240,335,`z = ${example.z}`)}
      {node('activation',335,105,'ReLU','负数归零')}{forward(440,530,`h = ${example.h}`)}
      {node('output',530,120,'第二层','w₂h + b₂')}{forward(650,754,`ŷ = ${example.prediction}`)}
      {node('loss',754,128,'平方损失','(ŷ − y)²')}{forward(882,938,'')}<text className={styles.finalValue} data-forward-loss x="969" y="105">L = {example.loss}</text>
      <text className={styles.parameter} x="180" y="156">w₁ = 1　b₁ = −1</text><text className={styles.parameter} x="590" y="156">w₂ = 2　b₂ = 0</text>
      <text className={styles.parameter} x="818" y="26">目标 y = 3</text><path className={styles.forwardLine} d="M818 35 V61 m-4 -6 l4 6 l4 -6"/>
      <text className={styles.reverseLaneLabel} x="22" y="215">反向 ← 梯度</text>
      {backward(960,818,'起点 1','start')}{backward(818,590,'对 ŷ：−2','loss')}{backward(590,387,'对 h：−4','output')}{backward(387,180,'对 z：−4','activation')}
      {[180,387,590,818].map(x=><line className={styles.connector} key={x} x1={x} x2={x} y1="170" y2="235" />)}
    </svg>
    <div className={styles.parameterResults} aria-label="这次反向得到的参数梯度">{(Object.keys(initial) as Array<keyof Parameters>).map(name=><div key={name} data-gradient={name} data-selected={selected===3?(name==='w1'||name==='b1'):selected===1?(name==='w2'||name==='b2'):false}><span>{parameterNames[name]} 的梯度</span><strong>{fmt(example.gradients[name])}</strong></div>)}</div>
    <div className={styles.stepArea}>
      <div className={styles.stepButtons} aria-label="选择反向计算步骤">{steps.map((item,i)=><button key={item.id} aria-pressed={i===selected} onClick={()=>setSelected(i)}>{item.label}</button>)}</div>
      <div className={styles.explanation} data-current-step={step.id}>
        <h3>{step.title}</h3><p>{step.description}</p>
        <div className={styles.gradientHeader}><span>计算谁的梯度</span><span>后面传来的梯度</span><span/><span>这一步的变化率</span><span/><span>传回的梯度</span></div>
        {step.rows.map(row=><div className={styles.gradientRow} key={row.to} data-gradient-row={row.to}><b>{row.to}</b><strong>{fmt(row.incoming)}</strong><span>×</span><div><strong>{fmt(row.local)}</strong><small>{row.rule}</small></div><span>=</span><strong>{fmt(row.result)}</strong></div>)}
        <p className={styles.stepNote}>{step.note}</p>
      </div>
    </div>
  </div>;
}
