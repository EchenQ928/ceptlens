import {Callout,CodeBlock,Formula,Paragraph,TermSection,defineTermView} from '@term-sdk';
import {BackpropExplorer} from './explorer';
import {after,example,fmt,initial,learningRate,parameterNames,updated,type Parameters} from './model';
import {backwardCode,updateCode} from './pytorch';
import styles from './styles.module.css';

function TermBody() {
  return <div className={styles.root}>
    <TermSection id="influence" title="先理解“改变一点，会影响多少”">
      <Paragraph>{'模型做出了预测，[[term:loss-function|损失函数]]也给出了分数。要继续训练，还需要知道：某个权重或偏置稍微变动，损失会增大还是减小？反向传播就是用来计算这种影响的方法。'}</Paragraph>
      <Paragraph>{'先从离损失最近的预测值看起。目标固定为 3，当前预测为 2，使用平方误差计分。把预测稍微增大一点，损失就会下降：'}</Paragraph>
      <div className={styles.sensitivity}><div><small>当前预测</small><strong>2</strong><p>平方损失：(2 − 3)² = 1</p></div><span>→</span><div><small>预测增加 0.01</small><strong>2.01</strong><p>平方损失：(2.01 − 3)² = 0.9801</p></div></div>
      <Paragraph>{'预测增加 0.01，损失大约减少 0.02。把变化量取得越来越小，“损失变化 ÷ 预测变化”就趋近 −2。这个局部变化率，就是损失对预测的梯度。反向传播会把这样的影响继续往前追，直到每个参数。'}</Paragraph>
      <Paragraph>{'梯度的正负表示方向：正值意味着这个量稍微增大，损失会增大；负值意味着损失会减小。梯度描述当前位置附近的变化，不是给参数直接加上的数。'}</Paragraph>
    </TermSection>
    <TermSection id="walk" title="沿同一张计算图往回追">
      <Paragraph>{'下面用一个很小的两层网络。第一层先乘权重、加偏置，再经过[[term:activation-function|激活函数]] ReLU；第二层得到预测，最后与目标比较。把运算及其先后关系连起来，就是计算图。'}</Paragraph>
      <Paragraph>{'先从左向右算出前向结果，再从损失开始向左计算梯度。每经过一步，都用“后面传来的梯度 × 这一步的局部变化率”。点击下方步骤，查看具体相乘的是哪两个数。'}</Paragraph>
      <BackpropExplorer />
      <details className={styles.forwardDetails}><summary>核对图中的前向数值</summary><div className={styles.arithmetic}><div><small>第一层</small><strong>z = 1 × 2 − 1 = 1</strong></div><div><small>激活</small><strong>h = ReLU(1) = 1</strong></div><div><small>第二层</small><strong>ŷ = 2 × 1 + 0 = 2</strong></div><div><small>平方损失</small><strong>L = (2 − 3)² = 1</strong></div></div></details>
    </TermSection>
    <TermSection id="chain" title="为什么逐步相乘就能追到参数">
      <Paragraph>{'第一层权重 w₁ 先影响 z，z 影响 h，h 影响预测，预测再影响损失。沿这条路径，把每一段的变化率乘起来，就得到损失对 w₁ 的梯度。这条规则叫链式法则。'}</Paragraph>
      <Formula expression={String.raw`\frac{\partial L}{\partial w_1}=\underbrace{\frac{\partial L}{\partial\hat y}}_{-2}\cdot\underbrace{\frac{\partial\hat y}{\partial h}}_{2}\cdot\underbrace{\frac{\partial h}{\partial z}}_{1}\cdot\underbrace{\frac{\partial z}{\partial w_1}}_{2}=-8`} symbols={[{symbol:String.raw`\frac{\partial L}{\partial w_1}`,meaning:'损失对第一层权重的梯度。符号表示其他独立量固定时，w₁ 的局部影响。'},{symbol:String.raw`\hat y,h,z`,meaning:'依次对应图中的预测、激活结果、第一层加权结果。'},{symbol:'L',meaning:'这次前向得到的平方损失。'}]} />
      <Paragraph>{'反向传播按这个顺序复用已经算出的梯度，不必为每个参数单独重算整条路径。前向的中间结果也会派上用场，例如第二层权重的梯度就用到了 h = 1。'}</Paragraph>
      <details className={styles.forwardDetails}><summary>如果一个量影响了多条路径呢？</summary><Paragraph>{'各条路径的影响需要相加。举一个额外的小例子：同一个 h 同时进入两项损失，第一项是 (2h − 3)²，第二项是 h²。在 h = 1 时，两条路径传回的梯度分别为 −4 和 +2，总影响就是 −2。'}</Paragraph><Formula expression={String.raw`L=L_a+L_b\quad\Longrightarrow\quad\frac{\partial L}{\partial h}=\frac{\partial L_a}{\partial h}+\frac{\partial L_b}{\partial h}=-4+2=-2`} symbols={[{symbol:'L_a,L_b',meaning:'两条路径上的损失，分别为 (2h−3)² 和 h²。'},{symbol:'h',meaning:'被两条路径共同使用的量；本例取 1。'}]} /><Paragraph>{'所以，同一条路径上按链式法则相乘，多条路径汇合时把梯度相加。'}</Paragraph></details>
    </TermSection>
    <TermSection id="update" title="梯度算完，才轮到参数更新">
      <Paragraph>{'梯度告诉我们局部方向，[[term:optimizer|优化器]]决定怎样使用它。最简单的梯度下降把“学习率 × 梯度”从参数中减去。学习率控制这一步走多远。'}</Paragraph>
      <Formula expression={String.raw`\theta_{\mathrm{new}}=\theta_{\mathrm{old}}-\eta\frac{\partial L}{\partial\theta}`} symbols={[{symbol:String.raw`\theta`,meaning:'任意一个待更新的参数。'},{symbol:String.raw`\eta`,meaning:'学习率。本例设为 0.025，所有参数按同一次反向的梯度同时更新。'}]} />
      <table className={styles.updateTable}><thead><tr><th>参数</th><th>原值</th><th>这次梯度</th><th>减去 0.025 × 梯度后</th></tr></thead><tbody>{(Object.keys(initial) as Array<keyof Parameters>).map(name=><tr key={name}><th>{parameterNames[name]}</th><td>{fmt(initial[name])}</td><td>{fmt(example.gradients[name])}</td><td>{fmt(updated[name])}</td></tr>)}</tbody></table>
      <div className={styles.afterUpdate}><div><span>用新参数重新预测</span><strong>2 → {fmt(after.prediction)}</strong></div><div><span>同一个目标 y = 3，重新计算损失</span><strong>1 → {fmt(after.loss)}</strong></div></div>
      <Paragraph>{'这是参数更新后的新一次前向，前面的讲解图仍保留旧参数。这个步长让示例损失降低了；步长过大也可能越过合适位置，让损失升高。训练会重复前向、反向和更新。'}</Paragraph>
    </TermSection>
    <TermSection id="pytorch" title="在 PyTorch 中复现">
      <Paragraph>{'PyTorch 会在前向时记录需要求导的运算关系。对损失调用 backward()，就会自动按这些关系反向计算，并把参数梯度存入 .grad。'}</Paragraph>
      <CodeBlock language="python" code={backwardCode} caption="requires_grad=True 表示需要跟踪这个参数的梯度。四个变量与图中的 w₁、b₁、w₂、b₂ 一一对应。" />
      <details className={styles.forwardDetails}><summary>接着执行一次参数更新</summary><CodeBlock language="python" code={updateCode} caption={`使用普通 SGD，学习率 ${learningRate}；与上面的参数对照表一致。`} /></details>
      <Paragraph>{'backward() 只计算梯度，optimizer.step() 才修改参数。PyTorch 默认累加梯度，因此每轮开始通常用 zero_grad() 清空上一轮的结果。'}</Paragraph>
      <Callout tone="key" title="总结">{'前向算出预测、损失和中间结果；反向沿计算关系，把局部影响逐步乘起来，遇到多条路径再相加，得到参数梯度；优化器随后使用梯度更新参数。'}</Callout>
      <p className={styles.source}>参考：<a href="https://docs.pytorch.org/tutorials/beginner/basics/autogradqs_tutorial.html" target="_blank" rel="noreferrer">PyTorch · 自动微分</a><a href="https://pytorch.org/blog/overview-of-pytorch-autograd-engine/" target="_blank" rel="noreferrer">Autograd 的链式计算</a></p>
    </TermSection>
  </div>;
}
export default defineTermView({termId:'backpropagation',Component:TermBody});
