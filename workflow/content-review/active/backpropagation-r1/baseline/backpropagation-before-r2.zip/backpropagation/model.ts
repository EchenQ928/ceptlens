export const fmt = (value:number, digits=6) => String(Number(value.toFixed(digits))).replace('-','−');
export type Parameters = {w1:number;b1:number;w2:number;b2:number};
export const initial:Parameters={w1:1,b1:-1,w2:2,b2:0};
export function evaluate(params:Parameters, x=2, target=3) {
  const z=params.w1*x+params.b1;
  const h=Math.max(0,z);
  const prediction=params.w2*h+params.b2;
  const loss=(prediction-target)**2;
  const predictionGradient=2*(prediction-target);
  const hGradient=predictionGradient*params.w2;
  const zGradient=hGradient*(z>0?1:0);
  const gradients={w1:zGradient*x,b1:zGradient,w2:predictionGradient*h,b2:predictionGradient};
  return {z,h,prediction,loss,predictionGradient,hGradient,zGradient,gradients};
}
export const example=evaluate(initial);
export const learningRate=0.025;
export const updated=Object.fromEntries(Object.entries(initial).map(([name,value])=>[name,value-learningRate*example.gradients[name as keyof Parameters]])) as Parameters;
export const after=evaluate(updated);
export const parameterNames:Record<keyof Parameters,string>={w1:'w₁',b1:'b₁',w2:'w₂',b2:'b₂'};
export const steps=[
  {id:'loss',label:'① 从损失开始',title:'先求损失对预测的梯度',description:'预测为 2，目标为 3。平方损失在这里的变化率是 2 × (2 − 3) = −2。负号说明：预测值稍微增大，损失就会减小。',rows:[{to:'预测 ŷ',incoming:1,local:-2,rule:'平方损失在预测为 2 时的变化率',result:-2}],note:'起点是损失对自身的梯度 1。反向传播从这里出发，逐步求出前面各个量的梯度。'},
  {id:'output',label:'② 经过第二层',title:'第二层把影响传给 h、w₂ 和 b₂',description:'第二层计算 ŷ = w₂h + b₂。h 增加一点，预测的变化是它的 w₂ 倍；w₂ 增加一点，预测的变化是它的 h 倍；偏置 b₂ 直接加到预测上。',rows:[{to:'中间结果 h',incoming:-2,local:2,rule:'乘权重 w₂ = 2',result:-4},{to:'权重 w₂',incoming:-2,local:1,rule:'乘前向保存的 h = 1',result:-2},{to:'偏置 b₂',incoming:-2,local:1,rule:'加法的变化率为 1',result:-2}],note:'同一个传入梯度 −2，分别乘以这一步对各个输入的变化率，就能同时算出不同量的影响。'},
  {id:'activation',label:'③ 经过激活',title:'正区间的 ReLU 原样传回梯度',description:'前向算出的 z = 1，大于 0。在这个位置 ReLU 保留原值，因此 z 增加一点，h 也增加同样多，局部变化率为 1。',rows:[{to:'第一层结果 z',incoming:-4,local:1,rule:'z > 0，ReLU 在这里的变化率为 1',result:-4}],note:'如果这一处 z < 0，ReLU 的输出在附近保持为 0，这条路径传回的梯度也会是 0。'},
  {id:'hidden',label:'④ 回到第一层',title:'把梯度传到最前面的参数',description:'第一层计算 z = w₁x + b₁，输入 x = 2。w₁ 改变一点，z 的变化是它的 2 倍；b₁ 直接相加，局部变化率为 1。',rows:[{to:'权重 w₁',incoming:-4,local:2,rule:'乘前向使用的输入 x = 2',result:-8},{to:'偏置 b₁',incoming:-4,local:1,rule:'加法的变化率为 1',result:-4}],note:'到这里，四个参数的梯度都已得到。整个反向过程使用这次前向的数值，尚未修改参数。'},
];
