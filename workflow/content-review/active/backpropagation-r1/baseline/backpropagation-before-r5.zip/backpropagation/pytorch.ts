export const trainingCode = `import torch

# 同一个输入、目标；参数顺序为 w1、b1、w2、b2
x, target = 2.0, 3.0
parameters = [
    torch.tensor(v, dtype=torch.float64, requires_grad=True)
    for v in [1.0, -1.0, 2.0, 0.0]
]
w1, b1, w2, b2 = parameters
optimizer = torch.optim.SGD(parameters, lr=0.025)

for round_id in range(1, 3):
    optimizer.zero_grad()  # 清空上一轮梯度，不能沿用旧数值

    # 1. 用当前参数重新前向，再计算本轮梯度
    z = w1 * x + b1
    h = torch.relu(z)
    prediction = w2 * h + b2
    loss = (prediction - target).square()
    loss.backward()       # 只求梯度，此时参数还未更新

    print("round", round_id)
    print("prediction:", round(prediction.item(), 6))
    print("gradients:", [round(p.grad.item(), 6) for p in parameters])

    # 2. 学习率缩放梯度，同时更新四个参数
    optimizer.step()

    with torch.no_grad():
        new_prediction = w2 * torch.relu(w1 * x + b1) + b2
        new_loss = (new_prediction - target).square()
    print("new loss:", round(new_loss.item(), 6))

# 第1轮：预测 2.0，梯度 [-8.0, -4.0, -2.0, -2.0]
# 第2轮：预测 3.125，梯度 [1.025, 0.5125, 0.375, 0.25]`;
