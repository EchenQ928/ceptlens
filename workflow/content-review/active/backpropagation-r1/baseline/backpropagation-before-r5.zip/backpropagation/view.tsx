import {Callout,CodeBlock,Formula,TermSection,defineTermView} from '@term-sdk';
import {BackpropExplorer,ParameterUpdate} from './explorer';
import {trainingCode} from './pytorch';
import styles from './styles.module.css';

function TermBody() {
  return <div className={styles.root}>
    <TermSection id="gradients" title="求梯度：先第二层，再第一层">
      <p>以一个两层小网络为例：第一层后接 ReLU，第二层输出预测，最后用平方误差计分。完整函数是：</p>
      <Formula expression={String.raw`\begin{aligned}\hat y&=w_2\,\sigma(w_1x+b_1)+b_2\\[5pt]L&=(\hat y-y)^2=\left[w_2\,\sigma(w_1x+b_1)+b_2-y\right]^2\end{aligned}`} symbols={[{symbol:String.raw`\theta`,meaning:'参数集合 (w₁, b₁, w₂, b₂)；求偏导时，输入 x 和目标 y 固定。'},{symbol:String.raw`\sigma`,meaning:'本例采用 ReLU 激活函数。'}]}/>
      <p>为看清函数内部的依赖关系，把中间结果记为 <strong>z = w₁x + b₁</strong>、<strong>h = σ(z)</strong>，于是 <strong>ŷ = w₂h + b₂</strong>。这是同一个函数的分段写法。</p>
      <p>本轮取 <strong>x = 2、y = 3</strong>，初始参数 <strong>(w₁, b₁, w₂, b₂) = (1, −1, 2, 0)</strong>。先按图前向计算，再求损失对参数的偏导：</p>
      <BackpropExplorer/>
      <details className={styles.details}><summary>多条路径、多个样本与 ReLU 的边界</summary><p>同一参数通过多条路径影响损失时，各路径的贡献相加。批次损失取平均时，参数梯度也取平均。ReLU 在 z &gt; 0 时导数为 1，在 z &lt; 0 时为 0；z = 0 处不可导，PyTorch 约定取 0。</p></details>
    </TermSection>
    <TermSection id="update" title="更新参数：学习率决定走多远">
      <p>梯度求出后，最简单的梯度下降按下面的规则更新每个参数：</p>
      <Formula expression={String.raw`\theta_{\mathrm{new}}=\theta_{\mathrm{old}}-\eta\frac{\partial L}{\partial\theta}`} symbols={[{symbol:String.raw`\theta`,meaning:'任意一个权重或偏置。'},{symbol:String.raw`\eta`,meaning:'学习率：人为设置的正数，用来缩放这次参数更新的幅度。'}]}/>
      <p><strong>负梯度给出局部下降方向，学习率决定沿这个方向走多远。</strong>梯度为负时，减去它会让参数增大；梯度为正时，参数减小。同一梯度下，学习率越大，改动越大，但步长过大可能使损失上升。</p>
      <p>学习率<strong>不参与本轮梯度的计算</strong>。它通过更新参数，改变下一轮的前向结果和梯度。下面连续执行两轮，每一轮都重新求梯度：</p>
      <ParameterUpdate/>
      <details className={styles.details}><summary>用 PyTorch 复现这两轮训练</summary><CodeBlock language="python" code={trainingCode} caption="对应默认学习率 0.025。每轮重新前向、backward() 求梯度，再由 step() 更新参数。"/></details>
      <Callout tone="key" title="总结">{'反向传播在当前参数处计算损失的梯度；优化器按学习率更新参数。参数改变后，下一轮重新前向并重新求梯度，不能直接重复使用上一轮的数值。'}</Callout>
      <p className={styles.source}>参考：<a href="https://docs.pytorch.org/tutorials/beginner/basics/autogradqs_tutorial.html" target="_blank" rel="noreferrer">PyTorch · 自动微分</a><a href="https://cs231n.github.io/optimization-2/" target="_blank" rel="noreferrer">Stanford CS231n · 计算图与链式法则</a></p>
    </TermSection>
  </div>;
}
export default defineTermView({termId:'backpropagation',Component:TermBody});
