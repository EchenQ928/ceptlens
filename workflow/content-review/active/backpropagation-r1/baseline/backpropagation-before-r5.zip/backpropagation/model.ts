export const fmt = (value:number, digits=8) => String(Number(value.toFixed(digits))).replace('-','−');
export type Parameters = {w1:number;b1:number;w2:number;b2:number};
export const initial:Parameters={w1:1,b1:-1,w2:2,b2:0};
export function evaluate(params:Parameters, x=2, target=3) {
  const z=params.w1*x+params.b1;
  const h=Math.max(0,z);
  const prediction=params.w2*h+params.b2;
  const loss=(prediction-target)**2;
  const predictionGradient=2*(prediction-target);
  const hGradient=predictionGradient*params.w2;
  const zGradient=hGradient*(z>0?1:0);
  const gradients={w1:zGradient*x,b1:zGradient,w2:predictionGradient*h,b2:predictionGradient};
  return {z,h,prediction,loss,predictionGradient,hGradient,zGradient,gradients};
}
export const example=evaluate(initial);
export const learningRate=0.025;
export const updated=Object.fromEntries(Object.entries(initial).map(([name,value])=>[name,value-learningRate*example.gradients[name as keyof Parameters]])) as Parameters;
export const after=evaluate(updated);
export const parameterNames:Record<keyof Parameters,string>={w1:'w₁',b1:'b₁',w2:'w₂',b2:'b₂'};
export const parameterKeys = ['w1','b1','w2','b2'] as const;
export const outputFirstKeys = ['w2','b2','w1','b1'] as const;
export function trainStep(params:Parameters,rate:number) {
  const before=evaluate(params);
  const next=Object.fromEntries(parameterKeys.map(key=>[key,params[key]-rate*before.gradients[key]])) as Parameters;
  return {params:{...params},before,next,after:evaluate(next)};
}
export function trainingRounds(rate:number) {
  const first=trainStep(initial,rate);
  return [first,trainStep(first.next,rate)];
}
export const parameterSymbols:Record<keyof Parameters,string>={w1:'w_1',b1:'b_1',w2:'w_2',b2:'b_2'};
export function derivativeFor(key:keyof Parameters,params:Parameters=initial,x=2,target=3) {
  const result=evaluate(params,x,target);
  const factors=[{partial:String.raw`\frac{\partial L}{\partial\hat y}`,expression:String.raw`2(\hat y-y)`,value:result.predictionGradient,node:'loss'}];
  if(key==='w1'||key==='b1')factors.push(
    {partial:String.raw`\frac{\partial\hat y}{\partial h}`,expression:'w_2',value:params.w2,node:'output'},
    {partial:String.raw`\frac{\partial h}{\partial z}`,expression:String.raw`\sigma'(z)`,value:result.z>0?1:0,node:'activation'},
    {partial:String.raw`\frac{\partial z}{\partial ${parameterSymbols[key]}}`,expression:key==='w1'?'x':'1',value:key==='w1'?x:1,node:'hidden'},
  );
  else factors.push({partial:String.raw`\frac{\partial\hat y}{\partial ${parameterSymbols[key]}}`,expression:key==='w2'?'h':'1',value:key==='w2'?result.h:1,node:'output'});
  return {factors,gradient:factors.reduce((product,factor)=>product*factor.value,1),path:[parameterNames[key],...(key==='w1'||key==='b1'?['z','h']:[]),'ŷ','L']};
}
