import {useEffect,useRef,useState} from 'react';
import {Formula} from '@term-sdk';
import {evaluate,example,fmt,initial,learningRate,parameterKeys,parameterNames,trainingRounds} from './model';
import styles from './styles.module.css';

export function BackpropExplorer() {
  return <div className={styles.gradientSection}>
    <Network/>
    <h3>先求损失对预测的偏导</h3>
    <p>参数先影响预测 ŷ，预测再决定损失 L。因此，对任一参数求导，要把<strong>“损失对预测的偏导”与“预测对参数的偏导”相乘</strong>。先计算所有参数都会用到的第一项，记作 g：</p>
    <Formula expression={String.raw`L=(\hat y-y)^2\quad\Longrightarrow\quad g=\frac{\partial L}{\partial\hat y}=2(\hat y-y)`} symbols={[]}/>
    <div className={styles.values}>
      <div><span>本轮预测 ŷ</span><strong>2</strong></div><div><span>目标 y</span><strong>3</strong></div><div><span>偏差 ŷ − y</span><strong>2 − 3 = −1</strong></div><div><span>本轮 g</span><strong data-initial-g>2 × (−1) = −2</strong></div>
    </div>
    <p className={styles.keyPoint}><strong>求导表达式固定，不代表梯度数值固定。</strong>把本轮前向得到的预测、目标和中间值代入，才得到本轮梯度。参数更新后，预测通常会改变，下一轮必须重新代入计算。</p>
    <h3>第二层：先求 w₂ 和 b₂，共用 g</h3>
    <p>第二层是 <strong>ŷ = w₂h + b₂</strong>。对 w₂ 求导得到 h，对 b₂ 求导得到 1；再分别乘上刚算出的 g = −2。本轮 h = 1：</p>
    <Formula expression={String.raw`\begin{aligned}\frac{\partial L}{\partial w_2}&=\frac{\partial L}{\partial\hat y}\cdot\frac{\partial\hat y}{\partial w_2}=g\cdot h=(-2)\times1=-2\\[7pt]\frac{\partial L}{\partial b_2}&=\frac{\partial L}{\partial\hat y}\cdot\frac{\partial\hat y}{\partial b_2}=g\cdot1=-2\end{aligned}`} symbols={[]}/>
    <h3>第一层：把已知的梯度继续传到 z</h3>
    <p>第一层参数通过 <strong>z → h → ŷ → L</strong> 影响损失。继续沿这条链求导，复用 g，得到损失对 z 的偏导 δ。这里 w₂ = 2，z = 1 &gt; 0，ReLU 的导数 σ′(z) = 1：</p>
    <Formula expression={String.raw`\begin{aligned}\delta=\frac{\partial L}{\partial z}&=\underbrace{\frac{\partial L}{\partial\hat y}}_{g}\cdot\frac{\partial\hat y}{\partial h}\cdot\frac{\partial h}{\partial z}\\[5pt]&=g\cdot w_2\cdot\sigma'(z)=(-2)\times2\times1=-4\end{aligned}`} symbols={[]}/>
    <p>再由 <strong>z = w₁x + b₁</strong> 求第一层的两个参数。本轮输入 x = 2，它们共用刚算出的 δ = −4：</p>
    <Formula expression={String.raw`\begin{aligned}\frac{\partial L}{\partial w_1}&=\frac{\partial L}{\partial z}\cdot\frac{\partial z}{\partial w_1}=\delta\cdot x=(-4)\times2=-8\\[7pt]\frac{\partial L}{\partial b_1}&=\frac{\partial L}{\partial z}\cdot\frac{\partial z}{\partial b_1}=\delta\cdot1=-4\end{aligned}`} symbols={[]}/>
    <p><strong>到这里，四个参数的梯度都已算出，参数本身还没有改变。</strong>从损失往前计算 g、δ，再复用它们求参数梯度，就是这个网络的反向传播。</p>
  </div>;
}

export function ParameterUpdate() {
  const [rate,setRate]=useState(learningRate);
  const [completed,setCompleted]=useState(0);
  const [selected,setSelected]=useState(0);
  const roundPanel=useRef<HTMLDivElement>(null);
  const currentPanel=useRef<HTMLDivElement>(null);
  useEffect(()=>{
    if(completed===0)return;
    const panel=completed===1?roundPanel:currentPanel;
    panel.current?.scrollIntoView?.({behavior:window.matchMedia?.('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});
  },[completed]);
  const rounds=trainingRounds(rate);
  const round=rounds[selected];
  const actualParams=completed===0?initial:rounds[completed-1].next;
  const actual=evaluate(actualParams);
  const done=selected<completed;
  const error=round.before.prediction-3;
  const signed=(value:number)=>value>0?`+${fmt(value,6)}`:fmt(value,6);
  const reset=()=>{setCompleted(0);setSelected(0);};
  const execute=()=>{if(completed>=2||selected!==completed)return;setCompleted(completed+1);setSelected(Math.min(completed+1,1));};
  return <div className={styles.training}>
    <div className={styles.rateControls}><strong>学习率 η</strong><div role="group" aria-label="选择学习率">{[.01,.025,.1].map(value=><button key={value} aria-pressed={rate===value} onClick={()=>{setRate(value);reset();}}>{value}</button>)}</div><span>切换后从初始参数重新演示两轮</span></div>
    <div className={styles.rateExample}>第一轮 w₁ 的梯度始终为 −8。当前学习率为 <strong>{rate}</strong>，更新量为 <strong>−{rate} × (−8) = +{fmt(rate*8)}</strong>，w₁ 将从 1 变为 <strong>{fmt(1+rate*8)}</strong>。</div>
    <div className={styles.roundTabs} role="group" aria-label="查看训练轮次">{[0,1].map(index=><button key={index} disabled={index>completed} aria-pressed={selected===index} onClick={()=>setSelected(index)}>第 {index+1} 轮{index<completed?' · 已更新':''}</button>)}<span>已完成 {completed} / 2 轮</span><button onClick={reset}>重新开始</button></div>
    <div className={styles.roundBody} ref={roundPanel} data-selected-round={selected+1}>
      <h3>第 {selected+1} 轮：{selected===0?'用初始参数求梯度':'用第一轮的新参数，重新求梯度'}</h3>
      <p>下面是<strong>本轮更新前</strong>的前向结果与梯度。输入 x = 2、目标 y = 3 始终不变。</p>
      <div className={styles.values}>
        <div><span>本轮预测 ŷ</span><strong data-round-prediction>{fmt(round.before.prediction,6)}</strong></div><div><span>目标 y</span><strong>3</strong></div><div><span>偏差 ŷ − y</span><strong data-round-error>{signed(error)}</strong></div><div><span>g = 2(ŷ − y)</span><strong data-round-g>{signed(round.before.predictionGradient)}</strong></div>
      </div>
      <p className={styles.roundInsight}>{selected===0?'本轮预测小于目标，g 为负数。这组参数下，四个参数的梯度也都为负数。':round.before.predictionGradient>0?'第一轮更新后预测超过了目标，g 变为正数。这组参数下，四个参数的梯度也转为正数，更新方向随之改变。':'第一轮更新后预测仍低于目标，但偏差已经改变；这一轮要使用重新算出的梯度。'}</p>
      <p className={styles.note}>本轮中间结果：z = {fmt(round.before.z,6)}，h = <b data-round-h>{fmt(round.before.h,6)}</b>。把本轮数值代入第一部分的四个求导式，得到下表梯度。</p>
      <table className={styles.updateTable}><thead><tr><th>参数</th><th>本轮更新前</th><th>本轮梯度</th><th>更新量 −η × 梯度</th><th>{done?'本轮更新后':'将更新为'}</th></tr></thead><tbody>{parameterKeys.map(key=><tr key={key}><th>{parameterNames[key]}</th><td>{fmt(round.params[key],6)}</td><td data-round-gradient={key}>{signed(round.before.gradients[key])}</td><td>{signed(-rate*round.before.gradients[key])}</td><td data-next-parameter={key}>{fmt(round.next[key],6)}</td></tr>)}</tbody></table>
      <div className={styles.applyRow}><button className={styles.primary} disabled={done||completed===2} onClick={execute}>{done?'本轮已完成':`执行第 ${selected+1} 轮更新`}</button><span>四个参数使用本轮梯度同时更新。</span></div>
    </div>
    <div className={styles.verification} ref={currentPanel} aria-live="polite" data-completed-rounds={completed}>
      <div><span>当前实际预测</span><strong data-current-prediction>{fmt(actual.prediction,6)}</strong><small>已完成 {completed} 次参数更新</small></div><div><span>当前实际损失</span><strong data-current-loss>{fmt(actual.loss,6)}</strong><small>初始损失为 1</small></div>
      <div className={styles.currentParameters}><span>当前实际参数</span>{parameterKeys.map(key=><small key={key}>{parameterNames[key]} = <b data-parameter={key}>{fmt(actualParams[key],6)}</b></small>)}</div>
    </div>
    <table className={styles.history}><thead><tr><th>轮次</th><th>更新前预测</th><th>本轮 g</th><th>更新后预测</th><th>更新后损失</th></tr></thead><tbody>{rounds.map((item,index)=><tr key={index}><th>第 {index+1} 轮</th><td>{index<=completed?fmt(item.before.prediction,6):'待计算'}</td><td>{index<=completed?signed(item.before.predictionGradient):'待计算'}</td><td>{index<completed?fmt(item.after.prediction,6):'待更新'}</td><td>{index<completed?fmt(item.after.loss,6):'待更新'}</td></tr>)}</tbody></table>
    {completed>0&&<p className={styles.keyPoint}>{actual.loss>example.loss?'这次步长把参数推得过远，损失反而比初始值大。梯度给出局部下降方向，过大的学习率仍可能导致损失上升。':completed===2?'两轮使用相同的求导公式，但各自代入不同的当前参数和前向结果。第二轮没有沿用第一轮的梯度。':'第一轮已完成；上方已代入新参数，显示第二轮重新算出的梯度。可以继续更新，或切回第 1 轮比较。'}</p>}
    <p className={styles.note}>数值最多显示六位小数，计算使用未舍入数值。两轮重复同一个样本，便于单独观察参数变化的影响。</p>
  </div>;
}

function Network() {
  const longPath=false;
  const node=(id:string,x:number,width:number,title:string,rule:string,_active:boolean)=><g data-node={id} data-selected={false}><rect className={styles.node} x={x} y="52" width={width} height="68" rx="4"/><text className={styles.nodeTitle} x={x+width/2} y="78">{title}</text><text className={styles.nodeRule} x={x+width/2} y="104">{rule}</text></g>;
  const edge=(from:number,to:number,label:string,_active=false)=><g><path className={styles.forwardLine} d={`M${from} 86 H${to} m-6 -4 l6 4 l-6 4`}/><text className={styles.edgeValue} x={(from+to)/2} y="69">{label}</text></g>;
  return <svg className={styles.graph} viewBox="0 0 1060 210" role="img" aria-label={`前向：输入2，z=1，h=1，预测2，损失1`}>
    <text className={styles.input} x="42" y="94">x = 2</text>
    {edge(80,112,'')}{node('hidden',112,136,'第一层','w₁x + b₁',longPath)}{edge(248,361,'z = 1',longPath)}
    {node('activation',361,96,'ReLU','σ(z)',longPath)}{edge(457,567,'h = 1',longPath)}
    {node('output',567,136,'第二层','w₂h + b₂',true)}{edge(703,836,'ŷ = 2',true)}
    {node('loss',836,126,'平方损失','(ŷ − y)²',true)}{edge(962,987,'',true)}<text className={styles.finalValue} data-forward-loss x="1020" y="94">L = 1</text>
    {parameterKeys.map(key=><text key={key} data-graph-parameter={key} data-selected={false} className={styles.parameter} x={key.endsWith('1')?180:635} y={key.startsWith('w')?153:181}>{key.startsWith('w')?'权重':'偏置'} {parameterNames[key]} = {fmt(initial[key])}</text>)}
    <text className={styles.targetLabel} x="899" y="23">目标 y = 3</text><path className={styles.forwardLine} d="M899 29 V48 m-4 -6 l4 6 l4 -6"/>
  </svg>;
}

