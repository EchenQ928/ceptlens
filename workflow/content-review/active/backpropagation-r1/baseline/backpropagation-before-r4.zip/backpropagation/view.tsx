import {Callout,CodeBlock,Formula,Paragraph,TermSection,defineTermView} from '@term-sdk';
import {BackpropExplorer,ParameterUpdate} from './explorer';
import {backwardCode,updateCode} from './pytorch';
import styles from './styles.module.css';

function TermBody() {
  return <div className={styles.root}>
    <TermSection id="function" title="把网络和损失写成一个函数">
      <p>以一个两层网络为例：第一层后接 ReLU，第二层输出预测，再用平方误差计分。把整个前向过程合起来：</p>
      <Formula expression={String.raw`\begin{aligned}\hat y=f_{\theta}(x)&=w_2\,\sigma(w_1x+b_1)+b_2\\[6pt]L(\theta;x,y)&=\left[w_2\,\sigma(w_1x+b_1)+b_2-y\right]^2\end{aligned}`} symbols={[{symbol:String.raw`\theta`,meaning:'参数集合 (w₁, b₁, w₂, b₂)；求导时输入 x 和目标 y 固定。'},{symbol:String.raw`\sigma`,meaning:'本例采用 ReLU 激活函数。'}]}/>
      <p>训练需要求的就是<strong>损失 L 对这四个参数的偏导</strong>，把它们放在一起就是参数梯度：</p>
      <Formula expression={String.raw`\nabla_{\theta}L=\left(\frac{\partial L}{\partial w_1},\frac{\partial L}{\partial b_1},\frac{\partial L}{\partial w_2},\frac{\partial L}{\partial b_2}\right)`} symbols={[]}/>
    </TermSection>
    <TermSection id="derivatives" title="沿计算链，对每个参数求偏导">
      <p>给中间结果命名：<strong>z = w₁x + b₁</strong>，<strong>h = σ(z)</strong>。演示取 x = 2、y = 3，参数 (w₁, b₁, w₂, b₂) = (1, −1, 2, 0)，前向得到 z = h = 1、ŷ = 2、L = 1。</p>
      <BackpropExplorer/>
      <p><strong>∂ŷ/∂θ 是预测对参数的偏导；训练用的是 ∂L/∂θ。</strong>还要乘上损失对预测的偏导，才得到参数梯度。</p>
    </TermSection>
    <TermSection id="reuse" title="反向传播如何复用计算，再更新参数">
      <p>四条求导链有公共部分。反向传播从损失开始，先求出这些公共项，再复用它们得到各参数的梯度：</p>
      <Formula expression={String.raw`\begin{aligned}g&=\frac{\partial L}{\partial\hat y}=2(\hat y-y)=-2\\[6pt]\delta&=\frac{\partial L}{\partial z}=g\cdot w_2\cdot\sigma'(z)=(-2)\times2\times1=-4\end{aligned}`} symbols={[]}/>
      <p>第二层的两个参数复用 <strong>g</strong>，第一层的两个参数复用 <strong>δ</strong>。这就是“从后往前计算梯度”的含义。得到梯度后，再用学习率 0.025 做一次梯度下降：</p>
      <ParameterUpdate/>
      <details className={styles.details}><summary>多条路径、多个样本与 ReLU 的边界</summary><p>同一参数沿多条路径影响损失时，各路径的贡献相加。批次损失取平均时，参数梯度也取平均。ReLU 在 z &gt; 0 时导数为 1，在 z &lt; 0 时为 0；z = 0 处不可导，PyTorch 约定取 0。更新后要重新求梯度，学习率过大可能使损失上升。</p></details>
    </TermSection>
    <TermSection id="pytorch" title="用 PyTorch 复现同一组计算">
      <Paragraph>{'loss.backward() 自动沿计算图求参数偏导，将结果写入各参数的 .grad；optimizer.step() 使用这些梯度更新参数。'}</Paragraph>
      <CodeBlock language="python" code={backwardCode} caption="四个参数与公式一一对应，梯度顺序为 w₁、b₁、w₂、b₂。"/>
      <details className={styles.details}><summary>接着执行参数更新</summary><CodeBlock language="python" code={updateCode} caption="与上方按钮使用相同的 SGD 更新，学习率为 0.025。"/></details>
      <Callout tone="key" title="总结">{'求导目标是损失对所有可学习参数的偏导。反向传播按链式法则从后往前计算并复用中间梯度；优化器随后使用这些梯度更新参数。'}</Callout>
      <p className={styles.source}>参考：<a href="https://docs.pytorch.org/tutorials/beginner/basics/autogradqs_tutorial.html" target="_blank" rel="noreferrer">PyTorch · 自动微分</a><a href="https://cs231n.github.io/optimization-2/" target="_blank" rel="noreferrer">Stanford CS231n · 计算图与链式法则</a></p>
    </TermSection>
  </div>;
}
export default defineTermView({termId:'backpropagation',Component:TermBody});
