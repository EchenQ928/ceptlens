import {useState} from 'react';
import {Formula} from '@term-sdk';
import {after,derivativeFor,example,fmt,initial,parameterKeys,parameterNames,parameterSymbols,updated,type Parameters} from './model';
import styles from './styles.module.css';

function Network({selected}:{selected:keyof Parameters}) {
  const longPath=selected==='w1'||selected==='b1';
  const node=(id:string,x:number,width:number,title:string,rule:string,active:boolean)=><g data-node={id} data-selected={active}><rect className={active?styles.selectedNode:styles.node} x={x} y="52" width={width} height="68" rx="4"/><text className={styles.nodeTitle} x={x+width/2} y="78">{title}</text><text className={styles.nodeRule} x={x+width/2} y="104">{rule}</text></g>;
  const edge=(from:number,to:number,label:string,active=false)=><g><path className={active?styles.activeLine:styles.forwardLine} d={`M${from} 86 H${to} m-6 -4 l6 4 l-6 4`}/><text className={styles.edgeValue} x={(from+to)/2} y="69">{label}</text></g>;
  return <svg className={styles.graph} viewBox="0 0 1060 210" role="img" aria-label={`前向：输入2，z=1，h=1，预测2，损失1；当前高亮${parameterNames[selected]}到损失的依赖路径`}>
    <text className={styles.input} x="42" y="94">x = 2</text>
    {edge(80,112,'')}{node('hidden',112,136,'第一层','w₁x + b₁',longPath)}{edge(248,361,'z = 1',longPath)}
    {node('activation',361,96,'ReLU','σ(z)',longPath)}{edge(457,567,'h = 1',longPath)}
    {node('output',567,136,'第二层','w₂h + b₂',true)}{edge(703,836,'ŷ = 2',true)}
    {node('loss',836,126,'平方损失','(ŷ − y)²',true)}{edge(962,987,'',true)}<text className={styles.finalValue} data-forward-loss x="1020" y="94">L = 1</text>
    {parameterKeys.map(key=><text key={key} data-graph-parameter={key} data-selected={key===selected} className={styles.parameter} x={key.endsWith('1')?180:635} y={key.startsWith('w')?153:181}>{key.startsWith('w')?'权重':'偏置'} {parameterNames[key]} = {fmt(initial[key])}</text>)}
    <text className={styles.targetLabel} x="899" y="23">目标 y = 3</text><path className={styles.forwardLine} d="M899 29 V48 m-4 -6 l4 6 l4 -6"/>
  </svg>;
}

export function BackpropExplorer() {
  const [selected,setSelected]=useState<keyof Parameters>('w1');
  const {factors,path,gradient}=derivativeFor(selected);
  const symbol=parameterSymbols[selected];
  const mark=(key:keyof Parameters)=>key===selected?String.raw`{\color{#c7000b}{${parameterSymbols[key]}}}`:parameterSymbols[key];
  const fullLoss=String.raw`\left[${mark('w2')}\sigma\!\left(${mark('w1')}x+${mark('b1')}\right)+${mark('b2')}-y\right]^2`;
  const expression=String.raw`\begin{aligned}
    \frac{\partial L}{\partial ${symbol}}&=\frac{\partial}{\partial ${symbol}}${fullLoss}\\[6pt]
    &= ${factors.map(f=>f.partial).join(String.raw`\cdot `)}\\[6pt]
    &= ${factors.map(f=>f.expression).join(String.raw`\cdot `)}\\[6pt]
    &= ${factors.map(f=>f.value<0?`(${f.value})`:String(f.value)).join(String.raw`\times `)} = ${gradient}
  \end{aligned}`;
  return <div className={styles.explorer}>
    <div className={styles.graphHeading}><strong>同一个函数的计算图</strong><span>选择参数，查看它到损失的完整求导链；前向数值保持不变。</span></div>
    <Network selected={selected}/>
    <div className={styles.parameterButtons} role="group" aria-label="选择求偏导的参数">{parameterKeys.map(key=><button key={key} aria-label={`查看${key.startsWith('w')?'权重':'偏置'} ${parameterNames[key]} 的偏导`} aria-pressed={selected===key} onClick={()=>setSelected(key)}><span>{key.startsWith('w')?'权重':'偏置'} {parameterNames[key]}</span><strong>梯度 {fmt(example.gradients[key])}</strong></button>)}</div>
    <div className={styles.derivation} data-selected-parameter={selected}>
      <div className={styles.path}><strong>依赖路径</strong><span data-dependency-path>{path.join(' → ')}</span></div>
      <div data-derivative-result={gradient} className={styles.derivativeFormula}><Formula expression={expression} symbols={[]}/></div>
      <p className={styles.note}>{selected==='w1'||selected==='b1'?'每一项偏导对应图中的一次运算。这里 z = 1 > 0，所以 ReLU 的导数 σ′(z) = 1。':selected==='w2'?'对第二层权重 w₂ 求导时，h 与 w₂ 无关，因此 ∂ŷ/∂w₂ = h = 1。':'偏置 b₂ 直接加到预测上，因此 ∂ŷ/∂b₂ = 1。'}</p>
    </div>
  </div>;
}

export function ParameterUpdate() {
  const [applied,setApplied]=useState(false);
  const current=applied?updated:initial;
  const result=applied?after:example;
  const common:Record<keyof Parameters,string>={w1:'δx = −8',b1:'δ = −4',w2:'gh = −2',b2:'g = −2'};
  return <div className={styles.update}>
    <table className={styles.updateTable}><thead><tr><th>参数</th><th>复用公共项得到梯度</th><th>新值 = 原值 − 0.025 × 梯度</th><th>当前值</th></tr></thead><tbody>{parameterKeys.map(key=><tr key={key}><th>{parameterNames[key]}</th><td>{common[key]}</td><td>{fmt(initial[key])} − 0.025 × ({fmt(example.gradients[key])}) = <strong>{fmt(updated[key])}</strong></td><td data-parameter={key}>{fmt(current[key])}</td></tr>)}</tbody></table>
    <div className={styles.applyRow}><button className={styles.primary} onClick={()=>setApplied(true)} disabled={applied}>{applied?'已完成这一次更新':'同时更新四个参数'}</button><button onClick={()=>setApplied(false)} disabled={!applied}>恢复更新前</button><span>使用同一次前向得到的梯度。</span></div>
    <div className={styles.verification} aria-live="polite" data-applied={applied}>
      <div><span>{applied?'更新后重新预测':'原参数的预测'}</span><strong data-current-prediction>{fmt(result.prediction)}</strong><small>目标 y = 3</small></div>
      <div><span>{applied?'更新后的损失':'原参数的损失'}</span><strong data-current-loss>{fmt(result.loss)}</strong><small>{applied?'原损失为 1':'L = (ŷ − 3)²'}</small></div>
      <p>{applied?'预测从 2 变为 3.125，损失降到 0.015625。下一轮会在新参数处重新求梯度。':'反向传播只计算梯度。点击按钮后，才按梯度下降更新参数并重新计算损失。'}</p>
    </div>
  </div>;
}
