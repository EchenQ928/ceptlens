import { Callout, CodeBlock, Comparison, CuratedVisual, DepthwiseConvolutionExplorer, EngineeringBoundaries, Flow, Formula, Paragraph, TermSection, defineTermView } from "@term-sdk";
import styles from "./styles.module.css";

function TermBody() {
  return <div className={styles.packageRoot}>
      <TermSection id="two-pass" title="前向与反向各做什么">
        <Flow steps={[{"label":"前向计算","detail":"输入依次经过各层，产生预测；同时保存反向需要的中间结果。"},{"label":"得到损失","detail":"损失函数比较预测和目标，产生一个标量训练信号。"},{"label":"反向计算","detail":"从损失向输入方向逐层计算局部梯度，并用链式法则连起来。"},{"label":"参数更新","detail":"[[term:optimizer|优化器]]读取参数梯度并调整权重。"}]} />
      </TermSection>
      <TermSection id="chain-rule" title="两步链式法则">
        <Paragraph>{"设输入 x 先变成中间量 u，再变成损失 L。x 对 L 的总影响，等于 x 对 u 的局部影响乘以 u 对 L 的局部影响。"}</Paragraph>
        <Formula expression="\\frac{\\partial L}{\\partial x}=\\frac{\\partial L}{\\partial u}\\cdot\\frac{\\partial u}{\\partial x}" symbols={[{"symbol":"x","meaning":"较早的输入或参数"},{"symbol":"u","meaning":"计算链中的中间结果"},{"symbol":"L","meaning":"末端损失"},{"symbol":"\\partial L/\\partial x","meaning":"x 改变一点时损失的变化率"}]} />
      </TermSection>
      <EngineeringBoundaries items={["训练内存不只包含参数，还包含反向传播需要保存的激活和梯度。","长计算链中局部梯度连续相乘，可能导致梯度消失或爆炸。"]} />
    </div>;
}

export default defineTermView({ termId: "backpropagation", Component: TermBody });
