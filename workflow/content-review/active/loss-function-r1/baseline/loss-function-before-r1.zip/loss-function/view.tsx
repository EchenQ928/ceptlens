import { Callout, CodeBlock, Comparison, CuratedVisual, DepthwiseConvolutionExplorer, EngineeringBoundaries, Flow, Formula, Paragraph, TermSection, defineTermView } from "@term-sdk";
import styles from "./styles.module.css";

function TermBody() {
  return <div className={styles.packageRoot}>
      <TermSection id="training-loop" title="它怎样驱动训练">
        <Flow steps={[{"label":"模型预测","detail":"前向传播得到预测值或类别分数。"},{"label":"计算差距","detail":"损失函数同时读取预测和真实目标，给出当前误差。"},{"label":"更新参数","detail":"[[term:backpropagation|反向传播]]计算梯度，[[term:optimizer|优化器]]沿着降低损失的方向调整参数。"}]} />
        <Callout tone="key" title="损失不等于最终业务指标">{"训练需要可求导的目标；最终验收可能看准确率、F1、NMSE、时延等另一组指标。两者必须相关，但通常不是同一个量。"}</Callout>
      </TermSection>
      <TermSection id="task-match" title="与任务配套">
        <Comparison columns={["任务","常见输出","常见损失"]} rows={[["回归","连续数值","均方误差、绝对误差"],["多分类","每个类别的分数","交叉熵"],["多标签分类","每个标签独立的分数","二元交叉熵"]]} />
      </TermSection>
      <EngineeringBoundaries items={["损失函数的缩放、不同损失项的权重会直接影响梯度量级和多任务平衡。","训练损失下降只能说明对训练目标变好，仍需[[term:validation-set|验证集]]判断泛化表现。"]} />
    </div>;
}

export default defineTermView({ termId: "loss-function", Component: TermBody });
