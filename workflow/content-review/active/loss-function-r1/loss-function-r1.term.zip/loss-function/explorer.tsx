import { useState } from 'react';
import { classificationExample, fmt, regressionExample } from './model';
import styles from './styles.module.css';

export function RegressionExplorer() {
  const [prediction, setPrediction] = useState(1);
  const state=regressionExample(prediction);
  const px=(p:number)=>50+p*75, py=(loss:number)=>278-loss*25;
  const squarePath=Array.from({length:121},(_,i)=>{const p=i/20;return `${i?'L':'M'}${px(p)} ${py((p-3)**2)}`;}).join(' ');
  return <div className={styles.explorer}>
    <div className={styles.widgetHeading}><h3>同一份偏差，两种计分方式</h3><p>目标固定为 3。调整样本 A 的预测，看绝对误差和平方误差怎样变化。</p></div>
    <div className={styles.plotGrid}>
      <svg className={styles.graph} viewBox="0 0 540 328" role="img" aria-label={`目标为3，预测为${prediction}；绝对误差${fmt(state.absolute[0])}，平方误差${fmt(state.squared[0],4)}`}>
        <text x="50" y="20" className={styles.axisLabel}>单个样本的损失</text>
        {[0,3,6,9].map(v=><g key={v}><line className={styles.gridLine} x1="50" x2="500" y1={py(v)} y2={py(v)}/><text className={styles.tick} x="38" y={py(v)+5} textAnchor="end">{v}</text></g>)}
        <line className={styles.axis} x1="50" x2="500" y1="278" y2="278" /><line className={styles.guide} x1={px(3)} x2={px(3)} y1="35" y2="278" />
        {[0,1,2,3,4,5,6].map(v=><text className={styles.tick} key={v} x={px(v)} y="300" textAnchor="middle">{v}</text>)}
        <text className={styles.axisLabel} x="500" y="323" textAnchor="end">预测值</text><text className={styles.tick} x={px(3)+8} y="43">目标 = 3</text>
        <path className={styles.absoluteCurve} d={`M50 ${py(3)} L275 278 L500 ${py(3)}`} /><path className={styles.curve} d={squarePath} />
        <line className={styles.guide} x1={px(prediction)} x2={px(prediction)} y1="278" y2={py(state.squared[0])} />
        <circle data-square-point cx={px(prediction)} cy={py(state.squared[0])} r="6" className={styles.point}/>
        <path data-absolute-point d={`M${px(prediction)} ${py(state.absolute[0])-6} l6 6 l-6 6 l-6 -6 Z`} fill="#555b63" stroke="white" strokeWidth="1.5" />
      </svg>
      <div className={styles.controls}>
        <label htmlFor="loss-prediction">样本 A 的预测 <output>{fmt(prediction)}</output></label>
        <input id="loss-prediction" aria-label="样本 A 的预测值" type="range" min="0" max="6" step="0.25" value={prediction} onChange={e=>setPrediction(Number(e.target.value))} />
        <div className={styles.presets}>{[1,3,5].map(v=><button key={v} onClick={()=>setPrediction(v)} aria-pressed={prediction===v}>{v===3?'刚好预测 3':`预测 ${v}`}</button>)}</div>
        <p className={styles.error}>偏差 = {fmt(prediction)} − 3 = <strong data-error>{fmt(state.errors[0])}</strong></p>
        <div className={styles.score}><span><i className={styles.absoluteKey}/>绝对误差 · 菱形</span><strong data-absolute>{fmt(state.absolute[0])}</strong><small>把偏差取绝对值</small></div>
        <div className={styles.score}><span><i className={styles.squareKey}/>平方误差 · 圆点</span><strong data-squared>{fmt(state.squared[0],4)}</strong><small>偏差 × 偏差</small></div>
      </div>
    </div>
    <div className={styles.batch}>
      <h3>多个样本：先分别计分，再求平均</h3>
      <p>继续使用样本 A；B、C 的预测固定。每个样本各占相同权重。</p>
      <table className={styles.table}><thead><tr><th>样本</th><th>预测</th><th>目标</th><th>带正负的偏差</th><th>绝对误差</th><th>平方误差</th></tr></thead><tbody>{state.predictions.map((p,i)=><tr key={i} data-editable={i===0}><th>{['A（可调）','B','C'][i]}</th><td>{fmt(p)}</td><td>3</td><td>{fmt(state.errors[i])}</td><td>{fmt(state.absolute[i])}</td><td>{fmt(state.squared[i],4)}</td></tr>)}</tbody></table>
      <div className={styles.averages}><div><span>平均绝对误差 · MAE</span><strong data-mae>({state.absolute.map(v=>fmt(v)).join(' + ')}) ÷ 3 ≈ {fmt(state.mae)}</strong></div><div><span>均方误差 · MSE</span><strong data-mse>({state.squared.map(v=>fmt(v,4)).join(' + ')}) ÷ 3 ≈ {fmt(state.mse)}</strong></div></div>
    </div>
  </div>;
}

export function ClassificationExplorer() {
  const [probability,setProbability]=useState(0.6);
  const state=classificationExample(probability);
  const px=(p:number)=>50+p*450, py=(loss:number)=>265-loss*45;
  const path=Array.from({length:199},(_,i)=>{const p=.01+i*.005;return `${i?'L':'M'}${px(p)} ${py(-Math.log(p))}`;}).join(' ');
  return <div className={styles.explorer}>
    <div className={styles.widgetHeading}><h3>正确类别：猫</h3><p>调整模型分给“猫”的概率，观察损失。狗和鸟的概率随之调整，总和始终为 1。</p></div>
    <div className={styles.plotGrid}>
      <svg className={styles.graph} viewBox="0 0 540 325" role="img" aria-label={`交叉熵曲线，正确类别的概率为${fmt(probability)}，损失为${fmt(state.loss)}`}>
        <text className={styles.axisLabel} x="50" y="20">这个样本的交叉熵损失</text>
        {[0,1,2,3,4,5].map(v=><g key={v}><line className={styles.gridLine} x1="50" x2="500" y1={py(v)} y2={py(v)}/><text className={styles.tick} x="38" y={py(v)+5} textAnchor="end">{v}</text></g>)}
        <line className={styles.axis} x1="50" x2="500" y1="265" y2="265" />
        {[0,.5,1].map(v=><text className={styles.tick} key={v} x={px(v)} y="289" textAnchor="middle">{v}</text>)}
        <text className={styles.axisLabel} x="500" y="317" textAnchor="end">正确类别的预测概率</text>
        <path className={styles.curve} d={path}/><path className={styles.guide} d={`M${px(probability)} 265 V${py(state.loss)} H50`}/><circle data-ce-point cx={px(probability)} cy={py(state.loss)} r="6" className={styles.point}/>
      </svg>
      <div className={styles.controls}>
        <label htmlFor="loss-probability">给猫的概率 <output>{fmt(probability*100)}%</output></label>
        <input id="loss-probability" aria-label="正确类别猫的预测概率" type="range" min="0.01" max="0.99" step="0.01" value={probability} onChange={e=>setProbability(Number(e.target.value))}/>
        <div className={styles.presets}>{[.1,.6,.9].map(v=><button key={v} aria-pressed={probability===v} onClick={()=>setProbability(v)}>{v*100}%</button>)}</div>
        <div className={styles.probabilities}>{state.probabilities.map((p,i)=><div key={i} className={styles.probabilityRow}><span>{['猫 ✓','狗','鸟'][i]}</span><div><i style={{width:`${p*100}%`}} data-correct={i===0}/></div><b data-probability={i}>{fmt(p*100)}%</b></div>)}</div>
        <div className={styles.ceResult}><span>当前交叉熵损失</span><strong data-ce-loss>{fmt(state.loss)}</strong><p>{probability<.5?'正确类别获得的概率偏低，损失较大。':'正确类别获得更多概率，损失向 0 靠近。'}</p></div>
      </div>
    </div>
    <p className={styles.footnote}>曲线由负对数规则计算。概率趋近 0 时，损失持续增大；控件从 1% 开始，以避免无穷大的读数。示例分数保留三位小数。</p>
  </div>;
}
