export const denseExample = {
  inputs: [1, 2, 3],
  units: [
    { id: 'A', weights: [1, 1, -1], bias: -1 },
    { id: 'B', weights: [2, -1, 1], bias: 0 }
  ]
};

export const units = denseExample.units.map(unit => {
  const products = denseExample.inputs.map((input, i) => input * unit.weights[i]);
  return { ...unit, products, sum: products.reduce((sum, product) => sum + product, 0) + unit.bias };
});
