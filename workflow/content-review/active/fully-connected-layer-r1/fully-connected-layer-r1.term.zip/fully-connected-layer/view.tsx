import { Callout, Formula, Paragraph, TermSection, defineTermView } from '@term-sdk';
import { ConnectionExplorer } from './explorer';
import styles from './styles.module.css';

function TermBody() {
  return <div className={styles.root}>
    <TermSection id="connections" title="每条连接都有一个权重">
      <Paragraph>{'看一个有 3 路输入、2 个计算单元的全连接层。A、B 都接收这 3 个数，因此共有 6 条连接。每条连接有自己的权重；即使接收的是同一路输入，A 和 B 也可以采用不同的权重。'}</Paragraph>
      <Paragraph>{'把每个单元的 3 个权重放在同一行，就得到右侧的权重表。A、B 分别按自己这一行的权重计算，再各加一个偏置，得到两个输出。'}</Paragraph>
      <ConnectionExplorer />
    </TermSection>
    <TermSection id="matrix" title="把整层计算写成矩阵">
      <Paragraph>{'刚才的权重表就是一个矩阵。每行对应一个输出单元，每列对应一路输入：第一行计算 A，第二行计算 B。把输入排成一列，矩阵乘法就能同时写出这两个单元的加权求和。'}</Paragraph>
      <Formula expression={String.raw`\underbrace{\begin{bmatrix}z_A\\z_B\end{bmatrix}}_{\mathbf z}=\underbrace{\begin{bmatrix}1&1&-1\\2&-1&1\end{bmatrix}}_W\underbrace{\begin{bmatrix}1\\2\\3\end{bmatrix}}_{\mathbf x}+\underbrace{\begin{bmatrix}-1\\0\end{bmatrix}}_{\mathbf b}=\begin{bmatrix}-1\\3\end{bmatrix}`} symbols={[{symbol:'W',meaning:'2 行、3 列的权重矩阵，与交互表格完全对应。'},{symbol:String.raw`\mathbf x`,meaning:'3 个输入数，按 x₁、x₂、x₃ 的顺序排成列向量。'},{symbol:String.raw`\mathbf b`,meaning:'A、B 各自的偏置。偏置加在求和之后，不属于某条输入连接。'},{symbol:String.raw`\mathbf z`,meaning:'A、B 传出的两个结果，尚未经过激活函数。'}]} />
      <Paragraph>{'写成通用形式，就是 z = Wx + b。本页采用列向量：若有 n 路输入、m 个输出单元，W 就有 m 行、n 列。每一行读取全部 n 路输入，算出一个结果。'}</Paragraph>
      <Formula expression={String.raw`\mathbf z=W\mathbf x+\mathbf b,\qquad W\in\mathbb R^{m\times n}`} symbols={[{symbol:'n',meaning:'输入数的个数，也叫输入特征维度。本例为 3。'},{symbol:'m',meaning:'输出单元数，也叫输出特征维度。本例为 2。'}]} />
    </TermSection>
    <TermSection id="activation" title="全连接之后，再做激活">
      <Paragraph>{'上面的全连接计算得到 −1 和 3。如果后面接一个 ReLU，它会分别处理这两个数：−1 变成 0，3 保持不变。'}</Paragraph>
      <div className={styles.activationFlow} aria-label="全连接的结果为负一和三，经过 ReLU 后变成零和三"><div><small>全连接结果 z</small><strong>[−1, 3]</strong></div><span>→</span><div><small>ReLU</small><strong>负数归零，其余保留</strong></div><span>→</span><div><small>激活后的结果 h</small><strong>[0, 3]</strong></div></div>
      <Paragraph>{'全连接负责组合输入特征，[[term:activation-function|激活函数]]进一步改变响应方式。在[[term:mlp|多层感知机（MLP）]]中，隐藏层通常把两者接起来，让多层网络能够表达更复杂的关系。输出层是否接激活、接哪一种，则由任务决定。'}</Paragraph>
      <Paragraph>{'全连接中的乘权重、求和、加偏置合起来，数学上叫仿射变换。它本身不产生 ReLU 这样的非线性；只叠加这类计算，最终仍能合并成一次同类变换。'}</Paragraph>
    </TermSection>
    <TermSection id="size" title="大小与参数数量">
      <Paragraph>{'输入维度由这一层接收到的特征决定；输出维度决定它要产生多少个新特征。全连接既可以把特征数变少，也可以把特征数变多或保持不变。这里的 3 → 2 就是把 3 个输入数组合成 2 个新结果。'}</Paragraph>
      <div className={styles.parameterCount}><div><small>每条连接一个权重</small><strong>3 × 2 = 6</strong></div><span>+</span><div><small>每个单元一个偏置</small><strong>2</strong></div><span>=</span><div><small>本层参数总数</small><strong>8</strong></div></div>
      <Paragraph>{'一般地，n 路输入、m 个输出单元需要 n×m 个权重。若使用偏置，再加 m 个参数；不使用偏置时，就只有这些权重。增加输入或输出维度，都会增加连接数和通常所需的计算量。'}</Paragraph>
      <Callout tone="key" title="总结">{'读全连接层，可以从一条连接看起：它对应一个权重。再看一个单元：它用一整行权重组合全部输入。最后看整层：把各行放在一起，就是权重矩阵。'}</Callout>
      <details className={styles.details}><summary>在代码里：Linear 与 Dense</summary><Paragraph>{'PyTorch 的 Linear 计算加权求和与可选偏置，激活通常另接一层。Keras 的 Dense 也提供激活参数，可以把这两步写在同一个层里。阅读代码时，确认是否配置了激活，就能对应回本页的计算过程。'}</Paragraph><p className={styles.source}>参考：<a href="https://docs.pytorch.org/docs/stable/generated/torch.nn.Linear.html" target="_blank" rel="noreferrer">PyTorch · Linear</a>、<a href="https://keras.io/api/layers/core_layers/dense/" target="_blank" rel="noreferrer">Keras · Dense</a></p></details>
    </TermSection>
  </div>;
}
export default defineTermView({ termId:'fully-connected-layer', Component:TermBody });
