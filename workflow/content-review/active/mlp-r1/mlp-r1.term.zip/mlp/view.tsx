import { Callout, Formula, Paragraph, TermSection, defineTermView } from '@term-sdk';
import { LayerExplorer } from './explorer';
import styles from './styles.module.css';

function TermBody() {
  return <div className={styles.root}>
    <TermSection id="layered-function" title="先看分层结构">
      <Paragraph>{'假设要根据设备的几项读数预测耗电量：读数是一组输入数字，预测值是输出。多层感知机在两者之间安排若干层计算，每层把收到的一组数字加工成一组新数字，再交给下一层。'}</Paragraph>
      <div className={styles.overview} aria-label="一组输入数字，经过隐藏层逐层加工，形成任务输出"><div><small>输入层</small><strong>接收原始数字</strong></div><span>→</span><div className={styles.middle}><small>一个或多个隐藏层</small><strong>组合信息，再做非线性变换</strong><span>上一层的结果，是下一层的输入</span></div><span>→</span><div><small>输出层</small><strong>得到任务输出</strong></div></div>
      <Paragraph>{'这里的“层”就是处于同一计算阶段的一组单元；一个单元也叫一个神经元。隐藏层位于输入与输出之间，产生供后续计算使用的中间结果。“隐藏”只是在说它的位置，这些计算完全可以展开查看。'}</Paragraph>
      <Paragraph>{'MLP 是英文 Multilayer Perceptron 的缩写，属于[[term:neural-network|神经网络]]。下面只保留两个输入、两个隐藏层和一个输出单元，把它的分层结构打开来看。'}</Paragraph>
    </TermSection>
    <TermSection id="connections" title="全连接怎样计算">
      <Paragraph>{'看下图的隐藏层 1：A、B 都接收 x₁ 和 x₂，每一路先乘一个权重，再把结果相加并加上偏置。权重决定这一路怎样参与组合，偏置在相加后额外调整总和。随后，两个单元各自对总和做一次 ReLU 处理：负数归零，其余保留。'}</Paragraph>
      <Paragraph>{'一个单元接收上一层的全部结果，叫[[term:fully-connected-layer|全连接]]。但“收到相同的数”不等于“做相同的计算”：每个单元有自己的权重和偏置。图中的 A 把两个输入相加后减 1，B 则计算两个输入的差。'}</Paragraph>
      <LayerExplorer />
      <Paragraph>{'图中只有相邻层之间的连接：同层单元各自计算，后一层接着处理前一层的结果。数值沿箭头从输入流向输出，不绕回前面的层；这就是前馈的计算方向。这里的全连接也不表示任意两个单元都互相连接。'}</Paragraph>
    </TermSection>
    <TermSection id="layer-composition" title="层与层怎样配合">
      <Paragraph>{'顺着同一张图往右走：第一隐藏层传出 [2, 0]，第二隐藏层便把这两个数当作输入。C、D 分别用自己的参数再次组合它们，传出 [1, 4]；输出层最后把 1 和 4 各乘 0.5，再相加得到 2.5。'}</Paragraph>
      <div className={styles.resultChain}><div><small>原始输入 x</small><strong>[1, 2]</strong></div><span>→</span><div><small>第一层结果 hA、hB</small><strong>[2, 0]</strong></div><span>→</span><div><small>第二层结果 hC、hD</small><strong>[1, 4]</strong></div><span>→</span><div><small>最终输出 y</small><strong>2.5</strong></div></div>
      <Paragraph>{'一层提供多种组合方式，下一层再组合这些结果。隐藏层传出的这一组数，叫作数据在这一层的“表示”：它仍来自同一个输入，只是已经被网络加工过。真实训练中，这些组合由数据和参数共同决定，不一定能把某个单元直接命名为“温度特征”或“负载特征”。'}</Paragraph>
      <h3 className={styles.subheading}>为什么每层还要有非线性处理？</h3>
      <Paragraph>{'乘权重、相加和加偏置已经能完成多种数值组合，比如缩放、求差、求平均。但如果每一层都只做这些操作，无论叠多少层，最终都可以合并成一次同类计算。分了更多步骤，却没有超出这类关系的范围。'}</Paragraph>
      <Paragraph>{'ReLU 让计算出现不同区间的响应：总和为负时传出 0，为正时传出原值。例如 B 的总和是 −1，却传出 0；下一层接收到的也就是 0。不同单元可以在不同输入条件下发生这种转折，后续层再组合它们，便能表达更丰富的关系。ReLU 是一种[[term:activation-function|激活函数]]，MLP 也可以采用其他非线性激活函数。'}</Paragraph>
      <Callout tone="key" title="多层，是逐级加工；非线性，让这种加工不只是合并算式">{'全连接负责把上一层的信息组合起来，非线性激活负责改变响应方式。两者配合，隐藏层才可以逐级构造更丰富的表示。'}</Callout>
    </TermSection>
    <TermSection id="width-depth" title="宽度与深度">
      <div className={styles.dimensions}><div><h3>宽度：一层有多少个单元</h3><p>图中两个隐藏层的宽度都是 2。增宽某一层，就能在这一层同时产生更多个中间结果；不同层的宽度可以不同。</p></div><div><h3>深度：经过多少层计算</h3><p>图中有 2 个隐藏层，再加 1 个输出层。若按带参数的计算层计数，就是 3 层；输入层只接收数据，不计入这个数。</p></div></div>
      <Paragraph>{'“多层感知机”不要求一定有很多隐藏层：只有一个隐藏层、再接输出层的结构，也可以是 MLP。交流具体结构时，直接说“几个隐藏层、各有几个单元”，比只说“几层网络”更清楚。'}</Paragraph>
      <Paragraph>{'更多单元或更多层提供了更大的建模空间，也通常增加参数与计算开销。它们不会自动带来更好的预测，仍需要合适的数据和训练，并在未参与训练的数据上检验效果。'}</Paragraph>
    </TermSection>
    <TermSection id="formula" title="把计算写成公式">
      <Paragraph>{'先把同一层的结果排成一列，就可以用一个向量表示整层输出；再把各个单元的权重排成一个矩阵。矩阵乘法在这里做的，正是图中各个单元的“逐路相乘，再相加”。下面按列向量来写，输入仍是 [1, 2]。'}</Paragraph>
      <Formula expression={String.raw`\begin{aligned}\mathbf{h}^{(1)}&=\operatorname{ReLU}\!\left(\underbrace{\begin{bmatrix}1&1\\1&-1\end{bmatrix}}_{W^{(1)}}\begin{bmatrix}1\\2\end{bmatrix}+\underbrace{\begin{bmatrix}-1\\0\end{bmatrix}}_{\mathbf b^{(1)}}\right)=\begin{bmatrix}2\\0\end{bmatrix}\\[8pt]\mathbf{h}^{(2)}&=\operatorname{ReLU}\!\left(\underbrace{\begin{bmatrix}1&2\\2&-1\end{bmatrix}}_{W^{(2)}}\begin{bmatrix}2\\0\end{bmatrix}+\underbrace{\begin{bmatrix}-1\\0\end{bmatrix}}_{\mathbf b^{(2)}}\right)=\begin{bmatrix}1\\4\end{bmatrix}\\[8pt]y&=\begin{bmatrix}0.5&0.5\end{bmatrix}\begin{bmatrix}1\\4\end{bmatrix}+0=2.5\end{aligned}`} symbols={[{symbol:String.raw`\mathbf h^{(1)},\mathbf h^{(2)}`,meaning:'第一、第二隐藏层的整组输出，分别由图中的 hA、hB 和 hC、hD 组成。括号里的数字是层号，不是乘方。'},{symbol:String.raw`W^{(1)},W^{(2)}`,meaning:'各层的权重矩阵。每一行属于一个单元，每一列对应这个单元接收的一路输入。'},{symbol:String.raw`\mathbf b^{(1)},\mathbf b^{(2)}`,meaning:'各层的偏置向量，每个单元各有一个偏置。'},{symbol:String.raw`\operatorname{ReLU}`,meaning:'分别处理向量中的每个数：负数变为 0，其余保持不变。'},{symbol:'y',meaning:'图中输出层的最终结果。这个示例的输出层直接保留加权求和结果。'}]} />
      <details className={styles.deeper}><summary>进一步：任意宽度的一层怎样表示？</summary>
        <Formula expression={String.raw`\mathbf h=\varphi(W\mathbf x+\mathbf b),\qquad W\in\mathbb R^{m\times n}`} symbols={[{symbol:String.raw`\mathbf x\in\mathbb R^n`,meaning:'本层收到的 n 个输入数，可以是原始输入，也可以是前一层的结果。'},{symbol:String.raw`\mathbf h\in\mathbb R^m`,meaning:'本层 m 个单元传出的 m 个结果。'},{symbol:'W',meaning:'m 行、n 列的权重矩阵：m 个单元，每个都接收 n 路输入。'},{symbol:String.raw`\mathbf b\in\mathbb R^m`,meaning:'每个单元的偏置，共 m 个。'},{symbol:String.raw`\varphi`,meaning:'本层采用的激活处理，如逐元素 ReLU。输出层的处理方式由任务决定。'}]} />
        <Paragraph>{'因此，一个带偏置的全连接层有 m×n 个权重和 m 个偏置。本页示例依次有 6、6、3 个参数，共 15 个。这里没有计算额外训练状态；参数量也不能直接等同于运行时延。'}</Paragraph>
      </details>
    </TermSection>
    <TermSection id="summary" title="训练与总结">
      <Paragraph>{'示例中，我们手工给每个单元设置了参数。真实任务通常先选好层数、宽度和激活函数，再通过训练调整权重和偏置：用[[term:loss-function|损失函数]]衡量输出与目标的差距，通过[[term:backpropagation|反向传播]]计算参数对这个差距的影响，再由优化算法更新参数。训练完成后，使用模型时通常固定参数，从左到右计算输出。'}</Paragraph>
      <Paragraph>{'MLP 可以根据一组特征预测数值，也可以做分类。输出层的大小和处理方式随任务变化：预测一个数值时可以只有一个输出；多类别分类时可以先输出各类别的分数，再用 softmax 等方式转换。输出不是天然就是概率。'}</Paragraph>
      <Callout tone="key" title="总结">{'多层感知机把全连接的计算层逐级接起来。每层用自己的参数组合上一层的结果，隐藏层再做非线性处理，最终得到任务需要的输出。读懂“接收哪组数、怎样组合、把哪组结果交给下一层”，就读懂了 MLP 的主要结构。'}</Callout>
      <p className={styles.source}>进一步阅读：<a href="https://d2l.ai/chapter_multilayer-perceptrons/mlp.html" target="_blank" rel="noreferrer">《动手学深度学习》· 多层感知机</a></p>
    </TermSection>
  </div>;
}
export default defineTermView({ termId:'mlp', Component:TermBody });
