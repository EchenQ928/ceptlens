import { Callout, Comparison, EngineeringBoundaries, Flow, Formula, Paragraph, TermSection, defineTermView } from "@term-sdk";
import { MlpForwardExplorer } from "./explorer";
import styles from "./styles.module.css";

function TermBody() {
  return <div className={styles.packageRoot}>
      <TermSection id="function-view" title="先把它当作一个函数">
        <Paragraph>{"从外部看，神经网络和普通函数做的是同一件事：接收输入 x，经过函数 F 的处理，得到输出 y。为了表示这是一个内部带有许多参数的函数，通常写成 Fθ；θ 代表这个函数内部全部参数的集合。"}</Paragraph>
        <div className={styles.functionBridge} aria-label="神经网络作为输入到输出的函数">
          <div><small>输入 x</small><b>图片、声音、文本或工程特征</b></div>
          <span>进入函数</span>
          <div className={styles.learnedFunction}><small>复杂函数</small><b>神经网络 F<sub>θ</sub></b><em>θ：函数内部全部参数的集合</em></div>
          <span>得到结果</span>
          <div><small>输出 y</small><b>类别、数值、序列或生成内容</b></div>
        </div>
        <div className={styles.unfoldCue}><span>打开中间的 F<sub>θ</sub></span><i>↓</i></div>
        <Paragraph>{"下面用一个很小的[[term:mlp|多层感知机（MLP）]]打开这个函数。图中只有两个输入、两个中间计算单元和两个输出。每个中间计算单元都与全部输入相连，因此这种结构也叫[[term:fully-connected-layer|全连接层]]。真实网络会更大，但组成方式相同：许多局部计算沿着连接一层层组合起来。"}</Paragraph>
        <MlpForwardExplorer />
        <Paragraph>{"现在可以给图中的参数正式命名：连接线公式里的 w 或 v 叫权重（weight），计算单元公式里的 b 或 c 叫偏置（bias）。这张网络中所有层的权重和偏置合在一起，就是前面 Fθ 中的[[term:model-parameter|参数 θ]]。网络结构规定哪些计算单元彼此连接，参数的具体数值则决定每一步怎样计算。把数据从左到右依次算到输出的过程叫[[term:forward-propagation|前向传播]]。"}</Paragraph>
      </TermSection>
      <TermSection id="rules-versus-learning" title="它与手写规则有什么不同">
        <Paragraph>{"传统程序通常由开发者明确写出“遇到什么条件就做什么”；神经网络则从许多输入—目标示例中学习一个数值映射。两者都是算法，只是规则存放的位置不同：前者主要写在可读代码里，后者大量分布在参数中。"}</Paragraph>
        <Comparison columns={["比较","手写规则函数","神经网络学到的函数"]} rows={[["映射怎样得到","开发者编写条件、流程和公式","开发者选结构，训练从数据中确定参数"],["更适合什么问题","规则清楚、稳定，并且必须严格审计","输入维度高、模式复杂，难以穷举规则"],["主要优势","行为直接、容易追踪，不需要先用样本训练","能从大量示例中提取特征并组合复杂模式"],["主要代价","规则变多后维护困难，难覆盖未枚举情况","依赖代表性数据和计算资源，内部决策通常更难直接读成规则"]]} />
        <div className={styles.nameOrigin}><b>为什么叫“神经网络”？</b><p>它把计算拆成许多小节点，节点之间用带权连接传递数值，再按层组成网络；这种形态受到生物神经元连接方式的启发。但工程中的神经网络是数学计算图，不是对大脑的忠实复制。它也并非“完全不可解释”，只是大量参数共同起作用，通常没有一条现成的人类规则可以直接读出。</p></div>
      </TermSection>
      <TermSection id="nonlinearity" title="为什么多层结构能表达复杂关系">
        <Paragraph>{"全连接层先做线性组合。若层与层之间没有非线性激活，不管叠多少层，最终仍能合并成一次线性变换，能表达的关系很有限。激活函数让中间结果发生非线性变化；多次交替“线性组合—非线性变换”，网络才能把输入空间分成不同区域并组合出弯曲、分段和层次化的映射。"}</Paragraph>
        <Formula expression={String.raw`W^{(2)}\!\left(W^{(1)}x+b^{(1)}\right)+b^{(2)}=\underbrace{W^{(2)}W^{(1)}}_{\text{仍是一个矩阵}}x+\underbrace{W^{(2)}b^{(1)}+b^{(2)}}_{\text{仍是一个偏置}}`} caption="只叠线性层时，多层最终仍等价于一个线性层。" symbols={[{"symbol":"x","meaning":"输入特征向量。"},{"symbol":"W^{(1)},W^{(2)}","meaning":"两层连接权重；合并后仍只是一个矩阵。"},{"symbol":"b^{(1)},b^{(2)}","meaning":"两层偏置；合并后仍只是一个偏置。"}]} />
        <Callout tone="key" title="能力来自两件事的配合">{"连接结构决定信息怎样流动，非线性决定网络能否跳出单一线性映射。足够合适的结构可以逼近许多复杂关系，但能否学好仍取决于数据、目标和训练过程。"}</Callout>
      </TermSection>
      <TermSection id="learning" title="权重和偏置从哪里来">
        <Paragraph>{"网络架构规定层数、连接方式和每层使用的运算；权重与偏置则决定这个具体函数当前会输出什么。训练时，[[term:loss-function|损失函数]]先把预测与目标之间的差距变成一个数值，[[term:backpropagation|反向传播]]再沿着前向计算链反向应用链式法则，算出每个参数对这份差距的影响。优化器据此小幅更新参数，重复许多次。"}</Paragraph>
        <Flow title="一次训练更新" steps={[{"label":"前向计算","detail":"把一批输入送入网络，得到当前预测。"},{"label":"计算损失","detail":"用一个数值表示预测与目标相差多少。"},{"label":"反向传播","detail":"计算每个权重和偏置对损失的影响方向。"},{"label":"更新参数","detail":"沿着让损失减小的方向小幅调整参数。"}]} />
        <Callout tone="note" title="结构与参数不要混在一起">{"常规训练主要更新权重和偏置，不会自动决定网络应该有几层、每层多宽或使用什么模块；这些属于架构与模块设计问题。"}</Callout>
      </TermSection>
      <EngineeringBoundaries items={["当输入维度高、规律难以显式枚举，并且有足够代表性数据时，神经网络通常更有优势，例如视觉、语音、文本和复杂信号处理。","当规则简单、必须严格满足、数据很少或需要逐条审计时，显式算法往往更可靠；工程系统也常把确定性规则与神经网络组合使用。","训练数据没有覆盖的新分布可能让网络失效。训练集表现好不等于真实环境一定可靠，还需要独立评测和边界测试。","更深、更宽的结构通常带来更强的表达能力，也会增加参数量、计算量、内存和过拟合风险；结构选择需要和任务、数据及部署预算一起权衡。","神经网络内部决策通常不像 if/else 一样直接可读，但可以通过特征可视化、归因分析、探针和受控实验等方法研究，不能简单等同于完全不可解释。"]} />
      <TermSection id="summary" title="总结">
        <Paragraph>{"神经网络的结构规定数据要经过哪些计算。训练过程再不断调整其中的权重和偏置，让这个函数逐渐形成任务需要的输入—输出关系。"}</Paragraph>
      </TermSection>
    </div>;
}

export default defineTermView({ termId: "neural-network", Component: TermBody });
