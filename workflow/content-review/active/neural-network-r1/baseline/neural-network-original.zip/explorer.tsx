import { Formula } from "@term-sdk";
import { useMemo, useState } from "react";
import styles from "./styles.module.css";

export const mlpExample: {
  input: number[];
  hiddenWeights: number[][];
  hiddenBias: number[];
  outputWeights: number[][];
  outputBias: number[];
} = {
  input: [1, 2],
  hiddenWeights: [[0.5, 1], [-1, 0.5]],
  hiddenBias: [-0.5, 1],
  outputWeights: [[1.5, -1], [-0.5, 1]],
  outputBias: [0, 0.5],
};

const relu = (value: number) => Math.max(0, value);
const sigmoid = (value: number) => 1 / (1 + Math.exp(-value));

export function calculateMlpExample() {
  const hiddenPreActivation = mlpExample.hiddenWeights.map((weights, node) =>
    weights.reduce((sum, weight, input) => sum + weight * mlpExample.input[input], mlpExample.hiddenBias[node])
  );
  const hidden = hiddenPreActivation.map(relu);
  const outputPreActivation = mlpExample.outputWeights.map((weights, node) =>
    weights.reduce((sum, weight, hiddenNode) => sum + weight * hidden[hiddenNode], mlpExample.outputBias[node])
  );
  return { hiddenPreActivation, hidden, outputPreActivation, output: outputPreActivation.map(sigmoid) };
}

const inputToHidden = [
  { from: 0, to: 0, weight: 0.5, symbol: "w₁₁", labelX: 74, labelY: 48 },
  { from: 0, to: 1, weight: -1, symbol: "w₂₁", labelX: 90, labelY: 103 },
  { from: 1, to: 0, weight: 1, symbol: "w₁₂", labelX: 90, labelY: 118 },
  { from: 1, to: 1, weight: 0.5, symbol: "w₂₂", labelX: 74, labelY: 176 },
];

const hiddenToOutput = [
  { from: 0, to: 0, weight: 1.5, symbol: "v₁₁", labelX: 74, labelY: 48 },
  { from: 0, to: 1, weight: -0.5, symbol: "v₂₁", labelX: 90, labelY: 103 },
  { from: 1, to: 0, weight: -1, symbol: "v₁₂", labelX: 90, labelY: 118 },
  { from: 1, to: 1, weight: 1, symbol: "v₂₂", labelX: 74, labelY: 176 },
];

const nodeY = [55, 165];
type SelectedTarget = { layer: "hidden" | "output"; index: number };

function Connections({ stage, target }: { stage: "hidden" | "output"; target: SelectedTarget }) {
  const connections = stage === "hidden" ? inputToHidden : hiddenToOutput;
  const label = stage === "hidden"
    ? target.layer === "hidden" ? `输入到隐藏节点 h${target.index + 1} 的当前计算路径` : "计算当前输出所需的全部输入到隐藏层连接"
    : target.layer === "output" ? `隐藏层到输出 y${target.index + 1} 的当前计算路径` : "输出层计算尚未展开";
  return <svg className={styles.connections} viewBox="0 0 180 220" role="img" aria-label={label}>
    {connections.map((edge) => {
      const active = stage === "hidden"
        ? target.layer === "output" || edge.to === target.index
        : target.layer === "output" && edge.to === target.index;
      return <g key={`${edge.from}-${edge.to}`} className={active ? styles.activeEdge : styles.inactiveEdge}>
        <line x1="4" y1={nodeY[edge.from]} x2="176" y2={nodeY[edge.to]} />
        <rect x={edge.labelX - 30} y={edge.labelY - 11} width="60" height="20" rx="4" />
        <text x={edge.labelX} y={edge.labelY + 3}>{edge.symbol}={edge.weight}</text>
      </g>;
    })}
  </svg>;
}

export function MlpForwardExplorer() {
  const [target, setTarget] = useState<SelectedTarget>({ layer: "hidden", index: 0 });
  const values = useMemo(calculateMlpExample, []);
  const hiddenExpressions = [
    String.raw`\begin{aligned}z_1&=w_{11}x_1+w_{12}x_2+b_1\\&=0.5\times1+1\times2-0.5=2\\h_1&=\operatorname{ReLU}(z_1)=2\end{aligned}`,
    String.raw`\begin{aligned}z_2&=w_{21}x_1+w_{22}x_2+b_2\\&=-1\times1+0.5\times2+1=1\\h_2&=\operatorname{ReLU}(z_2)=1\end{aligned}`,
  ];
  const outputExpressions = [
    String.raw`\begin{aligned}s_1&=v_{11}h_1+v_{12}h_2+c_1\\&=1.5\times2-1\times1+0=2\\y_1&=\sigma(s_1)=0.881\end{aligned}`,
    String.raw`\begin{aligned}s_2&=v_{21}h_1+v_{22}h_2+c_2\\&=-0.5\times2+1\times1+0.5=0.5\\y_2&=\sigma(s_2)=0.622\end{aligned}`,
  ];
  const expression = target.layer === "hidden" ? hiddenExpressions[target.index] : outputExpressions[target.index];
  const targetName = `${target.layer === "hidden" ? "h" : "y"}${target.index + 1}`;
  const symbols = target.layer === "hidden"
    ? [
      { symbol: "x_1,x_2", meaning: "进入这个计算单元的两个输入，本例取 1 和 2。" },
      { symbol: "w_{i1},w_{i2}", meaning: "写在连接线上的参数。每个输入先乘以对应的 w；这种参数叫权重（weight）。" },
      { symbol: "b_i", meaning: "求和后额外加上的参数。它不依赖某一条输入连接，叫偏置（bias）。" },
      { symbol: String.raw`\operatorname{ReLU}`, meaning: "这里使用的简单非线性处理：正数保持不变，负数变成 0。" },
    ]
    : [
      { symbol: "h_1,h_2", meaning: "上一层两个计算单元已经得到的结果；可点击它们查看各自的计算。" },
      { symbol: "v_{i1},v_{i2},c_i", meaning: "输出层自己的权重和偏置。字母可以不同，承担的角色与前一层相同。" },
      { symbol: "\sigma", meaning: "Sigmoid，把本例输出压到 0 到 1。" },
      { symbol: "y_i", meaning: "当前输出层计算单元的结果。" },
    ];

  return <figure className={styles.mlpExplorer}>
    <figcaption><strong>先看一个“小计算单元”怎样工作</strong><span>默认选中 h<sub>1</sub>；也可以点击其他 h 或 y。</span></figcaption>
    <div className={styles.networkLegend}><span><i className={styles.currentLine} />当前节点读取的连接</span><span><i className={styles.otherLine} />本次暂不参与的连接</span></div>
    <div className={styles.networkGrid}>
      <div className={styles.nodeColumn}>
        <b className={styles.columnTitle}>输入 x</b>
        <div className={styles.nodeCard}><strong>x<sub>1</sub> = {mlpExample.input[0]}</strong><small>输入特征 1</small></div>
        <div className={styles.nodeCard}><strong>x<sub>2</sub> = {mlpExample.input[1]}</strong><small>输入特征 2</small></div>
      </div>
      <Connections stage="hidden" target={target} />
      <div className={styles.nodeColumn}>
        <b className={styles.columnTitle}>中间层的计算单元</b>
        {values.hidden.map((value, index) => <button type="button" key={index} className={`${styles.nodeCard} ${styles.interactiveNode} ${target.layer === "hidden" && target.index === index ? styles.selectedNode : ""}`} onClick={() => setTarget({ layer: "hidden", index })} aria-pressed={target.layer === "hidden" && target.index === index}>
          <strong>h<sub>{index + 1}</sub> = {value}</strong><small>b<sub>{index + 1}</sub> = {mlpExample.hiddenBias[index] >= 0 ? "+" : ""}{mlpExample.hiddenBias[index]}</small>
          <em>{target.layer === "hidden" && target.index === index ? "正在拆解" : "点击拆解"}</em>
        </button>)}
      </div>
      <Connections stage="output" target={target} />
      <div className={styles.nodeColumn}>
        <b className={styles.columnTitle}>输出层的计算单元</b>
        {values.output.map((value, index) => <button type="button" key={index} className={`${styles.nodeCard} ${styles.interactiveNode} ${target.layer === "output" && target.index === index ? styles.selectedNode : ""}`} onClick={() => setTarget({ layer: "output", index })} aria-pressed={target.layer === "output" && target.index === index}>
          <strong>y<sub>{index + 1}</sub> = {value.toFixed(3)}</strong><small>c<sub>{index + 1}</sub> = {mlpExample.outputBias[index] >= 0 ? "+" : ""}{mlpExample.outputBias[index]}</small>
          <em>{target.layer === "output" && target.index === index ? "正在拆解" : "点击拆解"}</em>
        </button>)}
      </div>
    </div>
    <Formula expression={expression} caption={`当前拆解 ${targetName}：先看符号公式，再看同一行怎样代入图中的数值。`} symbols={symbols} />
    <p className={styles.explorerConclusion}>连接线上的参数决定每个输入要乘多少，计算单元自己的偏置决定求和后还要加多少。同样的局部计算在网络中反复出现，才组成上面的完整函数。</p>
  </figure>;
}
