import { describe, expect, it } from "vitest";
import { calculateMlpExample } from "./explorer";

describe("neural-network MLP example", () => {
  it("keeps diagram values, substitutions and outputs consistent", () => {
    const result = calculateMlpExample();
    expect(result.hiddenPreActivation).toEqual([2, 1]);
    expect(result.hidden).toEqual([2, 1]);
    expect(result.outputPreActivation).toEqual([2, 0.5]);
    expect(result.output[0]).toBeCloseTo(0.880797, 6);
    expect(result.output[1]).toBeCloseTo(0.622459, 6);
  });
});
