import { useId, useState } from "react";
import styles from "./styles.module.css";

// Keep the diagram and worked calculations tied to the same parameters.
export const mlpExample = {
  input: [1, 2], hiddenWeights: [[1, 1], [1, -1]], hiddenBias: [-1, 0],
  outputWeights: [0.5, 0.5], outputBias: 0,
};
export function calculateMlpExample(input1 = mlpExample.input[0]) {
  const input = [input1, mlpExample.input[1]];
  const hiddenPreActivation = mlpExample.hiddenWeights.map((weights, i) =>
    weights.reduce((sum, weight, j) => sum + weight * input[j], mlpExample.hiddenBias[i]));
  const hidden = hiddenPreActivation.map(value => Math.max(0, value));
  const output = hidden.reduce((sum, value, i) => sum + value * mlpExample.outputWeights[i], mlpExample.outputBias);
  return { input, hiddenPreActivation, hidden, output };
}
type Target = "a" | "b" | "output";
const fmt = (value: number) => Number(value.toFixed(2)).toString().replace("-", "−");
const factor = (value: number) => value < 0 ? `(${fmt(value)})` : fmt(value);

function Connections({ stage, target, marker }: { stage: "hidden" | "output"; target: Target; marker: string }) {
  const ys = [48, 156];
  return <svg className={styles.connections} viewBox="0 0 100 204" preserveAspectRatio="none" aria-hidden="true">
    <defs><marker id={marker} viewBox="0 0 10 10" refX="9" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="context-stroke" /></marker></defs>
    {ys.flatMap((y, from) => (stage === "hidden" ? ys : [102]).map((end, to) => {
      const active = stage === "output" ? target === "output" : (target === "a" && to === 0) || (target === "b" && to === 1);
      return <line key={`${from}-${to}`} x1="3" y1={y} x2="96" y2={end} markerEnd={`url(#${marker})`} className={active ? styles.activeEdge : styles.otherEdge} />;
    }))}
  </svg>;
}
export function MlpForwardExplorer() {
  const [target, setTarget] = useState<Target>("a");
  const [input1, setInput1] = useState(1);
  const id = useId().replaceAll(":", "");
  const values = calculateMlpExample(input1);
  const initial = calculateMlpExample();
  const index = target === "b" ? 1 : 0;
  const isOutput = target === "output";
  const name = isOutput ? "输出单元" : `单元 ${target.toUpperCase()}`;
  const sources = isOutput ? values.hidden : values.input;
  const labels = isOutput ? ["单元 A 的结果", "单元 B 的结果"] : ["输入 1", "输入 2"];
  const weights = isOutput ? mlpExample.outputWeights : mlpExample.hiddenWeights[index];
  const bias = isOutput ? mlpExample.outputBias : mlpExample.hiddenBias[index];
  const products = sources.map((value, i) => value * weights[i]);
  const total = isOutput ? values.output : values.hiddenPreActivation[index];
  const result = isOutput ? values.output : values.hidden[index];
  return <figure className={styles.explorer} aria-label="两输入、两隐藏单元、一输出的多层感知机">
    <figcaption><span className={styles.eyebrow}>打开函数 · 看数值怎样流动</span><strong>两个输入，经过一层中间计算，得到一个结果</strong></figcaption>
    <p className={styles.readHint}>从左往右读。A、B 都读取两个输入；输出单元再读取 A、B 的结果。</p>
    <div className={styles.network}>
      <div className={styles.column}><div className={styles.columnTitle}>输入层<small>送入数字</small></div><div className={styles.nodes}>
        {values.input.map((value, i) => <div className={styles.inputNode} key={i}><span>输入 {i + 1}</span><strong>{fmt(value)}</strong><small>{i === 0 ? "下方可调整" : "固定为 2"}</small></div>)}
      </div></div>
      <div className={styles.wires}><Connections stage="hidden" target={target} marker={`${id}-hidden`} /></div>
      <div className={styles.column}><div className={styles.columnTitle}>隐藏层<small>算中间结果</small></div><div className={styles.nodes}>
        {(["a", "b"] as const).map((key, i) => <button key={key} type="button" className={`${styles.computeNode} ${target === key ? styles.selected : ""}`} aria-pressed={target === key} aria-controls={`${id}-calculation`} aria-label={`查看单元 ${key.toUpperCase()} 的计算`} onClick={() => setTarget(key)}><span>单元 {key.toUpperCase()}</span><strong data-node={key}>{fmt(values.hidden[i])}</strong><small>{target === key ? "正在查看 ↓" : "查看计算"}</small></button>)}
      </div></div>
      <div className={styles.wires}><Connections stage="output" target={target} marker={`${id}-output`} /></div>
      <div className={styles.column}><div className={styles.columnTitle}>输出层<small>给出最终结果</small></div><div className={`${styles.nodes} ${styles.outputNodes}`}>
        <button type="button" className={`${styles.computeNode} ${styles.outputNode} ${isOutput ? styles.selected : ""}`} aria-pressed={isOutput} aria-controls={`${id}-calculation`} aria-label="查看输出单元的计算" onClick={() => setTarget("output")}><span>输出</span><strong data-node="output">{fmt(values.output)}</strong><small>{isOutput ? "正在查看 ↓" : "查看计算"}</small></button>
      </div></div>
    </div>
    <p className={styles.legend}><span className={styles.solidSample} />实线：连入当前查看的单元 <span className={styles.dashedSample} />虚线：其他连接</p>
    <p className={styles.clickHint}>点击 A、B 或输出，查看这个数是怎样算出来的。</p>
    <div className={styles.calculation} id={`${id}-calculation`} aria-live="polite" aria-atomic="true">
      <div className={styles.calculationHeading}><h3>{name} 怎样得到 <b>{fmt(result)}</b>？</h3><span>{isOutput ? "读取两个中间结果" : "读取两个输入"}</span></div>
      <div className={styles.calculationSteps}>
        <div className={styles.step}><h4><i>1</i>每路先乘一个数</h4><p>这个乘数叫<strong>权重</strong>，决定这一路按多大比例、正向还是反向计入。</p>
          <div className={styles.products}>{sources.map((value, i) => <div key={i}><small>{labels[i]} × 权重</small><b>{fmt(value)} × {factor(weights[i])} = {fmt(products[i])}</b></div>)}</div>
        </div>
        <div className={styles.step}><h4><i>2</i>相加，再加一个数</h4><p>额外加的数叫<strong>偏置</strong>，用于整体抬高或降低这份总和。</p><div className={styles.arithmetic}>{fmt(products[0])} + {factor(products[1])} {bias < 0 ? "−" : "+"} {fmt(Math.abs(bias))} = <b>{fmt(total)}</b><small>偏置 = {fmt(bias)}</small></div></div>
        <div className={styles.step}><h4><i>3</i>{isOutput ? "直接作为最终结果" : "负数归零，其余保留"}</h4><p>{isOutput ? "本例只输出一个数值，因此这里直接使用总和，不再做额外变换。" : "这种处理叫 ReLU，是一种激活函数：决定总和经过什么变换再传出去。"}</p><div className={styles.activation}><span>{fmt(total)}</span><span className={styles.activationArrow}>→<small>{isOutput ? "直接输出" : total < 0 ? "负数归零" : "保持原值"}</small></span><strong>{fmt(result)}</strong></div></div>
      </div>
      <p className={styles.localConclusion}>{isOutput ? `A 的 ${fmt(values.hidden[0])} 和 B 的 ${fmt(values.hidden[1])} 各乘 0.5，再加偏置 0，得到最终结果 ${fmt(values.output)}。` : `${name} 把 ${fmt(result)} 传给输出单元。${target === "b" && total < 0 ? "虽然它接收了输入，但负的总和经过 ReLU 后变成了 0。" : "下一层就把这个结果当作自己的输入。"}`}</p>
    </div>
    <div className={styles.experiment}>
      <h3>只改一个输入，结果会怎样变？</h3><p>拖动输入 1，看同一个网络怎样重新算出结果；输入 2、权重和偏置保持不变。</p>
      <div className={styles.sliderRow}><label htmlFor={`${id}-input`}>输入 1 <b>{fmt(input1)}</b></label><input id={`${id}-input`} type="range" min="0" max="3" step="0.5" value={input1} onChange={event => setInput1(Number(event.target.value))} aria-label="调整输入 1" /><button type="button" onClick={() => setInput1(1)} disabled={input1 === 1}>恢复为 1</button></div>
      <p className={styles.changeLabel}>对照初始状态：初始值 → 当前值</p>
      <div className={styles.changeSummary} aria-live="polite" aria-atomic="true"><span>输入 1<b>1 → {fmt(input1)}</b></span><span>单元 A<b>{initial.hidden[0]} → {fmt(values.hidden[0])}</b></span><span>单元 B<b>{initial.hidden[1]} → {fmt(values.hidden[1])}</b></span><span>最终输出<b>{initial.output} → {fmt(values.output)}</b></span></div>
      <p className={styles.experimentConclusion}>{input1 === 1 ? "试着把输入 1 拖到 3：除了 A 变大，B 也会从 0 变成正数。上面的计算会一起更新。" : input1 <= 2 ? `输入 1 现在是 ${fmt(input1)}。A 的结果随之改变；B 的总和是 ${fmt(values.hiddenPreActivation[1])}，经过 ReLU 后仍为 0。` : "输入 1 超过 2 后，B 的总和也成为正数，开始向输出贡献数值。因此输出对输入变化的响应，也在这里发生了改变。"}</p>
    </div>
    <p className={styles.footnote}>这是手工选定参数的演算示例，没有经过训练；输出只表示计算结果，不代表概率或真实任务的预测质量。</p>
  </figure>;
}
