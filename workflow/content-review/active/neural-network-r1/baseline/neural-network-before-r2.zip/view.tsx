import { Callout, Formula, Paragraph, TermSection, defineTermView } from "@term-sdk";
import { MlpForwardExplorer } from "./explorer";
import styles from "./styles.module.css";

function TermBody() {
  return <div className={styles.packageRoot}>
    <TermSection id="function-view" title="从外部看：一个函数">
      <Paragraph>{"如果你写过函数，就熟悉“给它输入，它返回结果”。神经网络也可以这样理解：比如输入一张图片，返回它属于哪一类；或者输入一组设备读数，预测一个数值。图片、声音和文字进入网络前，也会先表示成数字。"}</Paragraph>
      <div className={styles.functionBridge} aria-label="输入数字，经过神经网络内部的小计算单元，得到任务所需的结果">
        <div><small>输入</small><b>表示数据的数字</b></div><span aria-hidden="true">→</span><div className={styles.functionBox}><small>神经网络</small><b>许多相连的小计算单元</b><em>把计算结果继续传下去</em></div><span aria-hidden="true">→</span><div><small>输出</small><b>任务需要的结果</b></div>
      </div>
      <Paragraph>{"特别之处在函数内部：每个小单元用一些可以调整的数参与计算。训练时，程序根据大量例子反复调整这些数，让网络的输出逐渐接近希望得到的结果。我们先看这个函数怎样计算，再看这些数怎样学出来。"}</Paragraph>
    </TermSection>
    <TermSection id="inside-network" title="打开函数，跟着数字走">
      <Paragraph>{"下面把网络缩到可以手算的大小：两个输入数，先交给中间的 A、B 两个计算单元，再把它们的结果交给一个输出单元。同一阶段的单元排成一层；夹在输入和输出之间、负责产生中间结果的部分叫隐藏层。图中的 A、B 就在这个隐藏层里。"}</Paragraph>
      <Paragraph>{"这样的分层网络是一种[[term:mlp|多层感知机（MLP）]]。本例中，每个计算单元都接收上一层的全部结果，这种连接方式叫[[term:fully-connected-layer|全连接]]。箭头表示数值传递的方向。先看清这条路线，再看下方已经展开的单元 A。"}</Paragraph>
      <MlpForwardExplorer />
      <Paragraph>{"这些小计算单元也叫神经元。名字来自对生物神经元连接方式的借鉴，这里的单元做的是明确的数学运算。把输入沿连接一直算到输出，叫[[term:forward-propagation|前向传播]]。你刚才看到的就是一次前向计算，以及输入改变后重新计算的结果。"}</Paragraph>
    </TermSection>
    <TermSection id="nonlinearity" title="为什么能表达复杂关系">
      <Paragraph>{"回看单元 B：它先算“输入 1 减去输入 2”。本例输入 2 固定为 2，所以输入 1 不超过 2 时，B 传出去的始终是 0；超过 2 后，它才传出逐渐增大的正数。同样是把输入 1 增加一点，跨过这个位置后，输出增加得更快了。"}</Paragraph>
      <Paragraph>{"这种“不同区间采用不同响应方式”的关系，就是这里的非线性。ReLU 用一个简单的转折产生了它。ReLU 属于[[term:activation-function|激活函数]]：它对单元的加权总和做一次变换，再把结果交给下一层。"}</Paragraph>
      <Paragraph>{"更多单元可以用不同的权重和偏置，在不同输入条件下产生不同响应。后一层再组合前一层的结果，于是许多简单计算能组成复杂的函数。若各层始终只做乘常数和相加，叠起来仍能合并成一次这样的计算；非线性变换让这种组合获得了更多表达方式。"}</Paragraph>
      <Callout tone="key" title="把局部计算接起来，就是网络">{"每个单元做一小步，下一层接着处理上一层的结果。小例子展示的是一种常见结构；其他神经网络还会使用不同的连接方式和运算。"}</Callout>
    </TermSection>
    <TermSection id="learning" title="参数是怎样学出来的">
      <Paragraph>{"刚才每条连接上的乘数叫权重，每个单元额外加的数叫偏置。它们合起来属于网络的[[term:model-parameter|参数]]：在常规训练中，结构和计算规则先选好，训练主要调整这些参数。"}</Paragraph>
      <div className={styles.trainingStory}><h3>以“根据设备读数预测耗电量”为例</h3><ol><li><b>先算一次预测。</b>把一组读数送入网络，用当前参数算出预测耗电量。</li><li><b>和已知结果比较。</b>如果真实耗电量是 5 度，网络预测为 3 度，就还有差距。</li><li><b>调整参数，再尝试。</b>训练算法依据误差计算怎样小幅修改参数，再用许多这样的样本反复练习。</li></ol></div>
      <Paragraph>{"更具体地说，[[term:loss-function|损失函数]]把预测与已知结果之间的差距表示成一个数。[[term:backpropagation|反向传播]]计算参数的小变化会怎样影响这个差距，优化算法再据此调整参数。一次调整未必让每个样本都更好，训练是在许多样本上逐步改善整体表现。"}</Paragraph>
      <Paragraph>{"训练好以后，用网络处理新的输入，通常只需固定参数，像刚才的小网络一样从输入算到输出；这就是使用模型做推理。它能否在新数据上表现好，还需要用没参与训练的数据检验。"}</Paragraph>
    </TermSection>
    <TermSection id="formula" title="把计算写成公式">
      <Paragraph>{"下面回到小网络的初始状态：输入 1 为 1，输入 2 为 2。公式只是把前面的乘、加和负数归零写得更紧凑。这里用输入、单元 A、单元 B 的名称直接对应图中的位置。"}</Paragraph>
      <Formula expression={String.raw`\begin{aligned} A &= \max(0,\;1\times x_1+1\times x_2-1)\\ B &= \max(0,\;1\times x_1-1\times x_2+0)\\ y &= 0.5A+0.5B+0 \end{aligned}`} caption="初始输入代入后：A = 2，B = 0，输出 y = 1。这是固定的初始示例，不随上方滑块改变。" symbols={[{symbol:"x_1,x_2",meaning:"图中的输入 1 和输入 2。下标只用于区分两个输入。"},{symbol:"A,B",meaning:"图中单元 A、B 经过 ReLU 后传出的中间结果。"},{symbol:String.raw`\max(0,t)`,meaning:"取 0 与 t 中较大的数：负数归零，其余保留，也就是本例的 ReLU。"},{symbol:"y",meaning:"图中输出单元给出的最终数值。"}]} />
      <details className={styles.deeper}><summary>进一步：同样的计算怎样写成通用形式？</summary>
        <Paragraph>{"把单元 A 的两条输入连接上的权重写成两个 w，把偏置写成 b，把激活处理写成一个函数 φ，就得到下面的形式。它描述的仍是同一个小单元。"}</Paragraph>
        <Formula expression={String.raw`h=\varphi(w_1x_1+w_2x_2+b)`} symbols={[{symbol:"x_1,x_2",meaning:"这个单元接收到的两路输入；在后续层，它们也可以是上一层的计算结果。"},{symbol:"w_1,w_2",meaning:"两条输入连接各自的权重。本例单元 A 都为 1，单元 B 分别为 1 和 −1。"},{symbol:"b",meaning:"这个单元的偏置。本例 A 为 −1，B 为 0。"},{symbol:String.raw`\varphi`,meaning:"激活函数。本例隐藏层使用 ReLU；输出层直接保留总和。"},{symbol:"h",meaning:"这个单元传给下一层的结果。"}]} />
        <Paragraph>{"把许多这样的单元连接起来，整个网络可以记作一个带参数的函数。θ 是全部参数的统称：对本例来说，包括 6 个连接权重和 3 个偏置。输入数据会变，训练也可以改变 θ，从而改变这个函数的行为。"}</Paragraph>
        <Formula expression={String.raw`y=F_{\theta}(x)`} symbols={[{symbol:"x",meaning:"网络收到的整组输入。"},{symbol:String.raw`\theta`,meaning:"整个网络的参数集合，不是一个单独的数。"},{symbol:String.raw`F_{\theta}`,meaning:"使用当前这组参数的神经网络函数。"},{symbol:"y",meaning:"整个网络的输出。"}]} />
      </details>
    </TermSection>
    <TermSection id="takeaway" title="带走这条主线">
      <Paragraph>{"神经网络用许多相连的小计算单元组成一个函数。连接结构规定数值怎样流动，权重和偏置决定每一步怎样组合数值，激活函数引入非线性。训练通过调整参数，让这整个函数逐渐适合要解决的任务。"}</Paragraph>
      <Paragraph>{"在图片、语音等难以逐条写清规则的任务中，这种从数据中学习的方式很有用。但更大的网络并不自动带来更可靠的预测：数据是否有代表性、训练是否有效，以及新数据上的测试结果，都需要一起考虑。"}</Paragraph>
      <p className={styles.source}>进一步阅读：<a href="https://developers.google.com/machine-learning/crash-course/neural-networks/nodes-hidden-layers" target="_blank" rel="noreferrer">Google · 节点与隐藏层</a>、<a href="https://developers.google.com/machine-learning/crash-course/neural-networks/activation-functions" target="_blank" rel="noreferrer">激活函数</a></p>
    </TermSection>
  </div>;
}
export default defineTermView({ termId: "neural-network", Component: TermBody });
